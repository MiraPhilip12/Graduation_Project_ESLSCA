import customtkinter as ctk
import subprocess
import os

# ------------------------------
# App Configuration
# ------------------------------
ctk.set_appearance_mode("dark")  # "System", "Dark", or "Light"
ctk.set_default_color_theme("blue")


class VideoApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Window setup
        self.title("🎓 Graduation Project - Video Input")
        self.geometry("900x600")
        self.minsize(900, 600)
        self.configure(fg_color=("#f0f0f0", "#1a1a1a"))  # Light/Dark theme compatible

        # ------------------------------
        # Title Section
        # ------------------------------
        title_label = ctk.CTkLabel(
            self,
            text="🎥 Movement Analysis - Input Selection",
            font=("Helvetica", 28, "bold"),
            text_color=("#1a1a1a", "#e6e6e6")
        )
        title_label.pack(pady=(60, 30))

        subtitle = ctk.CTkLabel(
            self,
            text="Choose how you want to start your analysis:",
            font=("Helvetica", 16),
            text_color=("#333333", "#cccccc")
        )
        subtitle.pack(pady=(0, 40))

        # ------------------------------
        # Buttons Section
        # ------------------------------
        button_frame = ctk.CTkFrame(self, corner_radius=20)
        button_frame.pack(pady=30, padx=60, fill="both", expand=False)

        # Button styling
        button_style = {
            "width": 300,
            "height": 70,
            "corner_radius": 15,
            "font": ("Arial", 18, "bold")
        }

        # Open Camera
        self.camera_button = ctk.CTkButton(
            button_frame,
            text="📷 Open Camera",
            fg_color=("#0078D7", "#005A9E"),
            hover_color=("#339CFF", "#007ACC"),
            command=self.open_camera,
            **button_style
        )
        self.camera_button.pack(pady=30)

        # Choose Video File
        self.video_button = ctk.CTkButton(
            button_frame,
            text="🎞 Choose Video File",
            fg_color=("#28A745", "#1E7E34"),
            hover_color=("#34D058", "#218838"),
            command=self.choose_video,
            **button_style
        )
        self.video_button.pack(pady=30)

        # Exit Button
        self.exit_button = ctk.CTkButton(
            self,
            text="❌ Exit",
            fg_color=("#DC3545", "#A71D2A"),
            hover_color=("#FF4B5C", "#C82333"),
            font=("Arial", 16, "bold"),
            width=200,
            height=50,
            corner_radius=10,
            command=self.destroy
        )
        self.exit_button.pack(pady=40)

        # ------------------------------
        # Theme Switch
        # ------------------------------
        theme_switch = ctk.CTkSwitch(
            self,
            text="Dark Mode",
            command=self.toggle_theme
        )
        theme_switch.select()
        theme_switch.pack(pady=10)


    def open_camera(self):
        camera_script = r"camera_detGUI.py"  
        if os.path.exists(camera_script):
            subprocess.Popen(["python", camera_script])
        else:
            print(f"Camera script not found at: {camera_script}")

    
    def choose_video(self):
        video_script = r"video_detGUI.py"  
        if os.path.exists(video_script):
            subprocess.Popen(["python", video_script])
        else:
            print(f"Video script not found at: {video_script}")

        

    def toggle_theme(self):
        current = ctk.get_appearance_mode()
        if current == "Dark":
            ctk.set_appearance_mode("Light")
        else:
            ctk.set_appearance_mode("Dark")


# ------------------------------
# Run App
# ------------------------------
if __name__ == "__main__":
    app = VideoApp()
    app.mainloop()
