# ==============================================================
# CAMERA GUI (Integrated View + Analysis Box)
# ==============================================================
import cv2
import mediapipe as mp
import customtkinter as ctk
from PIL import Image, ImageTk
import threading
import time
from datetime import datetime


# Mediapipe setup
mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose


class CameraGUI(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("📷 Real-Time Posture & Emotion Detection")
        self.geometry("1200x700")
        self.minsize(1200, 700)

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        # -----------------------------------------------------
        # Layout: Left = Camera Feed | Right = Analysis Panel
        # -----------------------------------------------------
        self.grid_columnconfigure(0, weight=3)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # Camera Feed Label
        self.camera_label = ctk.CTkLabel(self, text="")
        self.camera_label.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")

        # Analysis Frame
        self.analysis_frame = ctk.CTkFrame(self, corner_radius=15)
        self.analysis_frame.grid(row=0, column=1, padx=20, pady=20, sticky="nsew")

        title = ctk.CTkLabel(
            self.analysis_frame,
            text="🧠 Live Analysis",
            font=("Helvetica", 22, "bold")
        )
        title.pack(pady=(20, 10))

        self.analysis_box = ctk.CTkTextbox(self.analysis_frame, width=300, height=400)
        self.analysis_box.pack(padx=20, pady=10, fill="both", expand=True)
        self.analysis_box.insert("end", "Waiting for camera input...\n")
        self.analysis_box.configure(state="disabled")

        # Buttons
        self.start_btn = ctk.CTkButton(
            self.analysis_frame,
            text="▶ Start Camera",
            command=self.start_camera_thread,
            width=200,
            height=50
        )
        self.start_btn.pack(pady=15)

        self.stop_btn = ctk.CTkButton(
            self.analysis_frame,
            text="⏹ Stop Camera",
            command=self.stop_camera,
            fg_color="#DC3545",
            hover_color="#C82333",
            width=200,
            height=50
        )
        self.stop_btn.pack(pady=15)

        self.running = False
        self.cap = None

    # -----------------------------------------------------
    # CAMERA THREAD
    # -----------------------------------------------------
    def start_camera_thread(self):
        if not self.running:
            self.running = True
            thread = threading.Thread(target=self.camera_loop)
            thread.start()

    def stop_camera(self):
        self.running = False
        time.sleep(0.3)
        if self.cap:
            self.cap.release()
        self.camera_label.configure(image="")
        self.update_analysis("Camera stopped.\n")

    # -----------------------------------------------------
    # MAIN CAMERA LOOP
    # -----------------------------------------------------
    def camera_loop(self):
        self.cap = cv2.VideoCapture(0)
        pose = mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5)

        while self.running:
            ret, frame = self.cap.read()
            if not ret:
                break

            frame = cv2.resize(frame, (800, 600))
            RGB = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = pose.process(RGB)

            posture = "Unknown"
            emotion = "Neutral"

            if results.pose_landmarks:
                landmarks = results.pose_landmarks.landmark
                left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value]
                right_shoulder = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value]
                left_hip = landmarks[mp_pose.PoseLandmark.LEFT_HIP.value]
                right_hip = landmarks[mp_pose.PoseLandmark.RIGHT_HIP.value]

                if left_shoulder.y < left_hip.y and right_shoulder.y < right_hip.y:
                    posture = "Standing"
                else:
                    posture = "Sitting / Leaning"

                mp_drawing.draw_landmarks(frame, results.pose_landmarks, mp_pose.POSE_CONNECTIONS)

            # Add overlay text
            cv2.putText(frame, f"Posture: {posture}", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.putText(frame, f"Emotion: {emotion}", (10, 70),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)

            # Convert frame to display in Tkinter
            img = Image.fromarray(frame)
            imgtk = ImageTk.PhotoImage(image=img)
            self.camera_label.imgtk = imgtk
            self.camera_label.configure(image=imgtk)

            # Update the analysis box
            log_text = f"[{datetime.now().strftime('%H:%M:%S')}] Posture: {posture} | Emotion: {emotion}\n"
            self.update_analysis(log_text)

            time.sleep(0.03)  # ~30 FPS

        self.cap.release()

    # -----------------------------------------------------
    # UPDATE ANALYSIS BOX
    # -----------------------------------------------------
    def update_analysis(self, text):
        self.analysis_box.configure(state="normal")
        self.analysis_box.insert("end", text)
        self.analysis_box.see("end")
        self.analysis_box.configure(state="disabled")


if __name__ == "__main__":
    app = CameraGUI()
    app.mainloop()
