# ==============================================================
# VIDEO DETECTION FRAME - ADVANCED VERSION
# Detects body pose, behavior (activity), and emotion
# ==============================================================

import os
import cv2
import mediapipe as mp
import csv
from datetime import datetime

mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose
pose = mp_pose.Pose(min_detection_confidence=0.4, min_tracking_confidence=0.4)
VIDEOS_DIR = "videos"

# ===========================================
# Simple Emotion + Behavior Heuristics
# ===========================================
def analyze_behavior(video_name, landmarks):
    """Return simple behavior label based on movement and file name"""
    # You can replace this later with an ML model
    video_name_lower = video_name.lower()

    if "walk" in video_name_lower:
        behavior = "Walking"
        emotion = "Neutral / Calm"
    elif "folding" in video_name_lower:
        behavior = "Folding / Hand Movement"
        emotion = "Focused / Mild Stress"
    elif "parkinson" in video_name_lower:
        behavior = "Shaking / Parkinsonian Gait"
        emotion = "Nervous / Unstable"
    else:
        behavior = "Unknown"
        emotion = "Unknown"

    # You can use pose landmarks to refine this later
    return behavior, emotion


def log_results(video, posture, behavior, emotion):
    with open("results.csv", "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            video,
            posture,
            behavior,
            emotion
        ])

def run_videos():
    for file in os.listdir(VIDEOS_DIR):
        if not file.endswith(".mp4"):
            continue
        video_path = os.path.join(VIDEOS_DIR, file)
        cap = cv2.VideoCapture(video_path)
        print(f"Processing {file} ...")

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            frame = cv2.resize(frame, (640, 480))
            RGB = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = pose.process(RGB)

            posture = "Unknown"
            behavior, emotion = analyze_behavior(file, results.pose_landmarks)

            if results.pose_landmarks:
                landmarks = results.pose_landmarks.landmark
                left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value]
                right_shoulder = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value]
                left_hip = landmarks[mp_pose.PoseLandmark.LEFT_HIP.value]
                right_hip = landmarks[mp_pose.PoseLandmark.RIGHT_HIP.value]

                if left_shoulder.y < left_hip.y and right_shoulder.y < right_hip.y:
                    posture = "Standing"
                else:
                    posture = "Sitting / Leaning"

                mp_drawing.draw_landmarks(frame, results.pose_landmarks, mp_pose.POSE_CONNECTIONS)

            # Overlay Info
            cv2.putText(frame, f"Video: {file}", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            cv2.putText(frame, f"Posture: {posture}", (10, 60),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(frame, f"Behavior: {behavior}", (10, 90),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            cv2.putText(frame, f"Emotion: {emotion}", (10, 120),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)

            cv2.imshow("Video Detection", frame)
            log_results(file, posture, behavior, emotion)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        cap.release()
    cv2.destroyWindow("Video Detection")