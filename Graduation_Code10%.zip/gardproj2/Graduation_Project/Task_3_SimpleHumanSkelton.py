# ==============================================================
# PSYCHOLOGICAL WELL-BEING ANALYZER (PHASE 1 - 10% SUBMISSION)
# Authors: Fatema Milad, Mehraeel Philip, Marwan Ahmed,
#          Jana Mahdy, Mo’men Mohy
#
# Features:
# - Live human pose detection using MediaPipe
# - Basic posture classification (Standing / Sitting)
# - Dummy emotion detection (for integration)
# - Logging of results to CSV file
# ==============================================================

import os
import cv2
import csv
from datetime import datetime
import mediapipe as mp

# ==========================
# Setup MediaPipe Pose model
# ==========================
mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose
pose = mp_pose.Pose(min_detection_confidence=0.4, min_tracking_confidence=0.4)

# ==========================
# Emotion Placeholder
# ==========================
def detect_emotion(frame):
    # Placeholder for future ML model integration
    # For now, always returns 'Neutral'
    return "Neutral"

# ==========================
# Results Logger
# ==========================
def log_results(posture, emotion):
    with open("results.csv", "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([datetime.now().strftime("%Y-%m-%d %H:%M:%S"), posture, emotion])

# ==========================
# Main Detection Loop
# ==========================
cap = cv2.VideoCapture(0)  # 0 for webcam | replace with filename for video
frame_count = 0

print("Starting Psychological Well-being Analyzer...")
print("Press 'Q' to quit.\n")

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        print("Can't receive frame (stream end?). Exiting ...")
        break

    frame = cv2.resize(frame, (640, 480))
    frame_count += 1

    # Convert to RGB
    RGB = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = pose.process(RGB)

    # Initialize default outputs
    posture = "Unknown"
    emotion = detect_emotion(frame)

    # ==========================
    # Posture Detection Logic
    # ==========================
    if results.pose_landmarks:
        landmarks = results.pose_landmarks.landmark
        left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value]
        right_shoulder = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value]
        left_hip = landmarks[mp_pose.PoseLandmark.LEFT_HIP.value]
        right_hip = landmarks[mp_pose.PoseLandmark.RIGHT_HIP.value]

        # Simple heuristic for standing/sitting
        if left_shoulder.y < left_hip.y and right_shoulder.y < right_hip.y:
            posture = "Standing"
        else:
            posture = "Sitting / Leaning"

        # Draw landmarks
        mp_drawing.draw_landmarks(frame, results.pose_landmarks, mp_pose.POSE_CONNECTIONS)

    # ==========================
    # Display Info on Frame
    # ==========================
    cv2.putText(frame, f"Posture: {posture}", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.putText(frame, f"Emotion: {emotion}", (10, 70),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)

    cv2.imshow('Psychological Well-being Analyzer', frame)

    # Log results
    log_results(posture, emotion)

    # Exit on 'Q' key
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

print("Session ended. Results saved to results.csv")
