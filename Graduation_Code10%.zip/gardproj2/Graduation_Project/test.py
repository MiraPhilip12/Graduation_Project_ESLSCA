import cv2

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("❌ Camera not detected — trying other indexes...")

    for i in range(1, 5):
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            print(f"✅ Camera opened successfully with index {i}")
            break
else:
    print("✅ Camera opened with index 0")

cap.release()
