# ==============================================================
# VIDEO DETECTION GUI (Layout + Placeholders)
# ==============================================================
import customtkinter as ctk
from tkinter import filedialog
from PIL import Image, ImageTk

class VideoGUI(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Window setup
        self.title("🎥 Video Detection System")
        self.geometry("1200x700")
        self.minsize(1200, 700)
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        # -----------------------------------------------------
        # LAYOUT CONFIGURATION
        # -----------------------------------------------------
        self.grid_columnconfigure(0, weight=3)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # -----------------------------------------------------
        # LEFT SIDE: Video Display Placeholder
        # -----------------------------------------------------
        self.video_frame = ctk.CTkFrame(self, corner_radius=15)
        self.video_frame.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")

        self.video_label = ctk.CTkLabel(
            self.video_frame,
            text="🎞 Video Preview Area",
            font=("Helvetica", 20, "bold"),
            text_color="#A0A0A0"
        )
        self.video_label.pack(expand=True)

        # -----------------------------------------------------
        # RIGHT SIDE: Controls + Analysis Box
        # -----------------------------------------------------
        self.control_frame = ctk.CTkFrame(self, corner_radius=15)
        self.control_frame.grid(row=0, column=1, padx=20, pady=20, sticky="nsew")

        # Title
        title_label = ctk.CTkLabel(
            self.control_frame,
            text="🧠 Video Analysis Panel",
            font=("Helvetica", 22, "bold")
        )
        title_label.pack(pady=(20, 10))

        # Add Video Button
        self.add_btn = ctk.CTkButton(
            self.control_frame,
            text="➕ Add Video(s)",
            width=200,
            height=45,
            command=self.add_videos  # Placeholder
        )
        self.add_btn.pack(pady=10)

        # Start Detection Button
        self.start_btn = ctk.CTkButton(
            self.control_frame,
            text="▶ Start Detection",
            width=200,
            height=45,
            command=self.start_detection  # Placeholder
        )
        self.start_btn.pack(pady=10)

        # Analysis Box
        self.analysis_box = ctk.CTkTextbox(self.control_frame, width=300, height=400)
        self.analysis_box.pack(padx=20, pady=15, fill="both", expand=True)
        self.analysis_box.insert("end", "Waiting for videos to be added...\n")
        self.analysis_box.configure(state="disabled")

        # Back Button
        self.back_btn = ctk.CTkButton(
            self.control_frame,
            text="⬅ Back to Main Menu",
            fg_color="#6c757d",
            hover_color="#5a6268",
            width=200,
            height=45,
            command=self.back_to_main  # Placeholder
        )
        self.back_btn.pack(pady=15)

    # -----------------------------------------------------
    # PLACEHOLDER FUNCTIONS
    # -----------------------------------------------------
    def add_videos(self):
        filedialog.askopenfilenames(
            title="Select Video Files",
            filetypes=[("MP4 files", "*.mp4"), ("All files", "*.*")]
        )
        self.update_analysis("📂 Videos selected (not loaded yet)...\n")

    def start_detection(self):
        self.update_analysis("🚀 Starting video detection (placeholder)...\n")

    def back_to_main(self):
        self.update_analysis("⬅ Returning to main GUI (placeholder)...\n")

    def update_analysis(self, text):
        self.analysis_box.configure(state="normal")
        self.analysis_box.insert("end", text)
        self.analysis_box.see("end")
        self.analysis_box.configure(state="disabled")


if __name__ == "__main__":
    app = VideoGUI()
    app.mainloop()
