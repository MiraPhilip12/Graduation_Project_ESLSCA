# ==============================================================
# MAIN LAUNCHER
# ==============================================================

from camera_detection import run_camera
from video_detection import run_videos

print("\n=== PSYCHOLOGICAL WELL-BEING ANALYZER ===")
print("1. Run Live Camera Detection")
print("2. Run Video Detection (from videos folder)")
choice = input("Enter your choice (1/2): ")

if choice == "1":
    run_camera()
elif choice == "2":
    run_videos()
else:
    print("Invalid choice. Exiting...")
