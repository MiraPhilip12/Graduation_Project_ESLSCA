# ==============================================================
# CAMERA DETECTION FRAME - WORKING VERSION
# ==============================================================
import os
import cv2
import mediapipe as mp
import csv
from datetime import datetime

mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose

def detect_emotion(frame):
    return "Neutral"

def log_results(source, posture, emotion):
    with open("results.csv", "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([datetime.now().strftime("%Y-%m-%d %H:%M:%S"), source, posture, emotion])

def run_camera():
    # Use DirectShow backend for Windows
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    
    if not cap.isOpened():
        print("❌ Error: Could not open camera")
        return
    
    # Initialize pose detection
    pose = mp_pose.Pose(
        min_detection_confidence=0.4, 
        min_tracking_confidence=0.4,
        model_complexity=1
    )
    
    print(" Starting camera detection...")
    print(" Press 'Q' to quit the camera feed")
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            print("❌ Failed to grab frame")
            break
            
        # Resize frame
        frame = cv2.resize(frame, (640, 480))
        
        # Convert to RGB for MediaPipe
        RGB = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = pose.process(RGB)

        posture = "Unknown"
        emotion = detect_emotion(frame)

        # Posture detection logic
        if results.pose_landmarks:
            landmarks = results.pose_landmarks.landmark
            
            # Get shoulder and hip landmarks
            left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value]
            right_shoulder = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value]
            left_hip = landmarks[mp_pose.PoseLandmark.LEFT_HIP.value]
            right_hip = landmarks[mp_pose.PoseLandmark.RIGHT_HIP.value]

            # Simple posture detection based on shoulder and hip positions
            if left_shoulder.y < left_hip.y and right_shoulder.y < right_hip.y:
                posture = "Standing"
            else:
                posture = "Sitting / Leaning"

            # Draw pose landmarks on the frame
            mp_drawing.draw_landmarks(
                frame, 
                results.pose_landmarks, 
                mp_pose.POSE_CONNECTIONS,
                mp_drawing.DrawingSpec(color=(0, 255, 0), thickness=2, circle_radius=2),
                mp_drawing.DrawingSpec(color=(255, 0, 0), thickness=2, circle_radius=2)
            )

        # Display posture and emotion text
        cv2.putText(frame, f"Posture: {posture}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.putText(frame, f"Emotion: {emotion}", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)
        cv2.putText(frame, "Press 'Q' to quit", (10, 450), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        # Show the frame
        cv2.imshow("Camera Detection - Posture Analysis", frame)

        # Log results to CSV
        log_results("Camera", posture, emotion)

        # Break loop when 'Q' is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Cleanup
    cap.release()
    cv2.destroyAllWindows()
    print("✅ Camera released successfully")

# THIS IS IMPORTANT - CALL THE FUNCTION
if __name__ == "__main__":
    run_camera()