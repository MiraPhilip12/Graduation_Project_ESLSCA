# repair_scikitplot_interp.py
import importlib.util, os, re, sys, shutil

spec = importlib.util.find_spec('scikitplot')
if spec is None or not spec.submodule_search_locations:
    print("scikitplot package not found in this Python environment.")
    sys.exit(1)

pkg_dir = spec.submodule_search_locations[0]
print("scikitplot package directory:", pkg_dir)

pattern = re.compile(r'^[ \t]*from\s+scipy\s+import\s+interp\s*$', flags=re.MULTILINE)

replacement = (
    "try:\n"
    "    from scipy import interp\n"
    "except Exception:\n"
    "    from numpy import interp\n"
)

patched = []
for root, dirs, files in os.walk(pkg_dir):
    for fname in files:
        if not fname.endswith('.py'):
            continue
        path = os.path.join(root, fname)
        with open(path, 'r', encoding='utf-8') as f:
            src = f.read()
        if pattern.search(src):
            bak = path + '.orig.bak'
            if not os.path.exists(bak):
                shutil.copy2(path, bak)
                print("Backup:", bak)
            new_src = pattern.sub(replacement, src)
            with open(path, 'w', encoding='utf-8') as f:
                f.write(new_src)
            patched.append(path)
            print("Patched:", path)

if not patched:
    print("No files patched (no top-level 'from scipy import interp' found).")
else:
    print("Patched files count:", len(patched))
    # remove __pycache__ to avoid stale bytecode
    pycache = os.path.join(pkg_dir, '__pycache__')
    if os.path.isdir(pycache):
        try:
            import shutil
            shutil.rmtree(pycache)
            print("Removed __pycache__")
        except Exception as e:
            print("Could not remove __pycache__:", e)
