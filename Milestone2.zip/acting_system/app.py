# app.py
import streamlit as st
from detector import ThreadedVideoCapture, MediapipeWrapper
from audio_vad import VADStream
import joblib
import cv2
import numpy as np
import threading
import time
from collections import deque

st.set_page_config(layout="wide")
st.title("Hand/Face/Emotion Real-time Demo (Streamlit)")

# Layout: left = video, right = status
col_video, col_status = st.columns([3, 1])
img_pl = col_video.empty()

# Load models if they exist (safe: will return None if not)
@st.cache_resource
def load_models():
    try:
        m = {}
        try:
            m['emotion'] = joblib.load("models/emotion_model.pkl")
        except Exception:
            m['emotion'] = None
        return m
    except Exception:
        return {'emotion': None}

models = load_models()

# choose camera index (0 worked for you)
CAM_INDEX = 0
FRAME_W, FRAME_H = 640, 480

# Start capture and processing in background thread
cap = ThreadedVideoCapture(CAM_INDEX, width=FRAME_W, height=FRAME_H)
mpwrap = MediapipeWrapper(detection_conf=0.5, tracking_conf=0.5)

# Start VAD
vad = VADStream(aggressiveness=2, vad_sr=16000, frame_ms=30, buffer_seconds=1.0)
try:
    vad.start()
except Exception as e:
    st.error(f"Failed to start VAD: {e}")

# label smoothing buffer to avoid flicker
label_buffer = deque(maxlen=8)

stop_flag = threading.Event()

def processing_loop(stop_event):
    # simple FPS calc
    last_time = time.time()
    while not stop_event.is_set():
        frame = cap.read_latest()
        if frame is None:
            time.sleep(0.01)
            continue

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        data, annotated = mpwrap.process(rgb)

        # Build consistent feature vector (same ordering used for training).
        def flatten_landmarks(arr, n):
            if arr is None:
                return [0.0] * (n * 3)
            arr2 = arr.reshape(-1, 3)
            out = arr2.flatten().tolist()
            if len(out) < n * 3:
                out += [0.0] * (n * 3 - len(out))
            return out

        features = []
        features += flatten_landmarks(data.get("face_landmarks"), 468)
        features += flatten_landmarks(data.get("left_hand"), 21)
        features += flatten_landmarks(data.get("right_hand"), 21)
        features += flatten_landmarks(data.get("pose"), 33)

        # Predict with model if available
        pred_label = "unknown"
        if models.get('emotion') is not None:
            try:
                X = np.array(features).reshape(1, -1)
                pred_label = models['emotion'].predict(X)[0]
            except Exception:
                pred_label = "err"

        # smoothing majority vote
        label_buffer.append(pred_label)
        if len(label_buffer) > 0:
            current_label = max(set(label_buffer), key=label_buffer.count)
        else:
            current_label = pred_label

        # annotate annotated image
        try:
            bgr = cv2.cvtColor(annotated, cv2.COLOR_RGB2BGR)
            cv2.putText(bgr, f"Label: {current_label}", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
            if vad.is_speaking:
                cv2.putText(bgr, "SPEAKING", (10, 60),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        except Exception:
            bgr = frame

        # display
        img_pl.image(bgr, channels="BGR")

        # status sidebar
        with col_status:
            st.subheader("Status")
            st.write("Predicted:", current_label)
            st.write("Speaking:", bool(vad.is_speaking))
            st.write("Buffer length:", len(label_buffer))
            st.write("Frame size:", bgr.shape if bgr is not None else "N/A")
            # Very approximate FPS
            now = time.time()
            fps = 1.0 / max(1e-6, (now - last_time))
            st.write("Approx FPS:", round(fps, 2))
            last_time = now

        # small sleep to yield
        time.sleep(0.01)

# Start thread
worker = threading.Thread(target=processing_loop, args=(stop_flag,), daemon=True)
worker.start()

st.write("Streamlit running. Click STOP to end the app.")

if st.button("STOP"):
    stop_flag.set()
    try:
        cap.stop()
    except Exception:
        pass
    try:
        vad.stop()
    except Exception:
        pass
    st.stop()
