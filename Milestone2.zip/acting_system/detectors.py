# detectors.py
import cv2
import mediapipe as mp

# MediaPipe solution singletons (created once for reuse)
mp_face = mp.solutions.face_mesh
mp_hands = mp.solutions.hands
mp_pose = mp.solutions.pose

# Tweak confidences for robustness
FACE = mp_face.FaceMesh(
    static_image_mode=False,
    max_num_faces=4,
    refine_landmarks=True,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

HANDS = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=4,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

POSE = mp_pose.Pose(
    static_image_mode=False,
    model_complexity=1,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

# ------------------------------------------------------------
def to_rgb(frame):
    """Convert BGR OpenCV image to RGB expected by MediaPipe"""
    return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

# ------------------------------------------------------------
class FaceDetectionResult:
    def __init__(self, landmarks):
        self.landmarks = landmarks

class HandDetectionResult:
    def __init__(self, landmarks, label=None):
        self.landmarks = landmarks
        self.label = label

class PoseDetectionResult:
    def __init__(self, landmarks):
        self.landmarks = landmarks

# ------------------------------------------------------------
class FaceDetector:
    """Wrap MediaPipe FaceMesh and return FaceDetectionResult objects"""
    def detect(self, frame):
        rgb = to_rgb(frame)
        res = FACE.process(rgb)
        faces = []
        if res and getattr(res, "multi_face_landmarks", None):
            for lm in res.multi_face_landmarks:
                faces.append(FaceDetectionResult(lm))
        return faces

# ------------------------------------------------------------
class HandDetector:
    """Wrap MediaPipe Hands and return HandDetectionResult objects"""
    def detect(self, frame):
        rgb = to_rgb(frame)
        res = HANDS.process(rgb)
        hands = []
        if res:
            multi_landmarks = getattr(res, "multi_hand_landmarks", None)
            multi_handedness = getattr(res, "multi_handedness", None)
            if multi_landmarks:
                handed = []
                if multi_handedness:
                    for h in multi_handedness:
                        try:
                            handed.append(h.classification[0].label)  # 'Left'/'Right'
                        except:
                            handed.append(None)
                for i, lm in enumerate(multi_landmarks):
                    label = handed[i] if i < len(handed) else None
                    hands.append(HandDetectionResult(lm, label))
        return hands

# ------------------------------------------------------------
class PoseDetector:
    """Wrap MediaPipe Pose and return PoseDetectionResult objects"""
    def detect(self, frame):
        rgb = to_rgb(frame)
        res = POSE.process(rgb)
        poses = []
        if res and getattr(res, "pose_landmarks", None):
            poses.append(PoseDetectionResult(res.pose_landmarks))
        return poses

# ------------------------------------------------------------
class EmotionDetector:
    """
    Lightweight heuristic emotion estimator:
    Returns one of: Happy, Sad, Angry, Confused, Surprised, Neutral, Crying
    """
    def detect_emotion(self, face_lms):
        if not face_lms or len(face_lms) < 15:
            return "Neutral"

        def get(i):
            return face_lms[i] if i < len(face_lms) else face_lms[0]

        # Mouth metrics
        mouth_w = abs(get(291)[0] - get(61)[0])
        mouth_h = abs(get(14)[1] - get(13)[1])

        # Eyes metrics
        left_eye = abs(get(159)[1] - get(145)[1])
        right_eye = abs(get(386)[1] - get(374)[1])
        eye_h = (left_eye + right_eye) / 2

        # Brows metrics
        browL = get(70)[1]
        browR = get(300)[1]
        nose = get(1)[1]

        # Heuristic rules
        if mouth_h > 0.05 and eye_h > 0.02:
            return "Surprised"
        if mouth_w > 0.06 and mouth_h > 0.02:
            return "Happy"
        if mouth_h < 0.02 and get(13)[1] > nose + 0.015:
            return "Sad"
        if browL < nose + 0.02 and browR < nose + 0.02:
            return "Angry"
        if abs(browL - browR) > 0.02:
            return "Confused"
        if mouth_h > 0.06 and eye_h < 0.01:
            return "Crying"
        return "Neutral"
