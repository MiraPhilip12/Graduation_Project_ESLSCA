# detectors.py
import cv2
import mediapipe as mp

mp_face = mp.solutions.face_mesh
mp_hands = mp.solutions.hands
mp_pose = mp.solutions.pose

FACE = mp_face.FaceMesh(static_image_mode=False, max_num_faces=4, refine_landmarks=True,
                        min_detection_confidence=0.5, min_tracking_confidence=0.5)
HANDS = mp_hands.Hands(static_image_mode=False, max_num_hands=4,
                       min_detection_confidence=0.5, min_tracking_confidence=0.5)
POSE = mp_pose.Pose(static_image_mode=False, model_complexity=1,
                    min_detection_confidence=0.5, min_tracking_confidence=0.5)

def to_rgb(frame):
    return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

class FaceDetector:
    def detect(self, frame):
        rgb = to_rgb(frame)
        res = FACE.process(rgb)
        faces = []
        if res.multi_face_landmarks:
            for lm in res.multi_face_landmarks:
                faces.append(type("F", (), {"landmarks": lm}))
        return faces

class HandDetector:
    def detect(self, frame):
        rgb = to_rgb(frame)
        res = HANDS.process(rgb)
        hands = []
        if res.multi_hand_landmarks:
            handed = []
            if res.multi_handedness:
                for h in res.multi_handedness:
                    handed.append(h.classification[0].label)  # 'Left'/'Right' subject side
            for i, lm in enumerate(res.multi_hand_landmarks):
                label = handed[i] if i < len(handed) else None
                hands.append(type("H", (), {"landmarks": lm, "label": label}))
        return hands

class PoseDetector:
    def detect(self, frame):
        rgb = to_rgb(frame)
        res = POSE.process(rgb)
        poses = []
        if res.pose_landmarks:
            poses.append(type("P", (), {"landmarks": res.pose_landmarks}))
        return poses

class EmotionDetector:
    def detect_emotion(self, face_lms):
        """
        face_lms: list of (x,y) normalized points (approx same indexing as mediapipe face mesh)
        returns one of: Happy, Sad, Angry, Confused, Neutral
        """
        L = face_lms
        def get(i): return L[i] if i < len(L) else L[0]
        left_mouth_x = get(61)[0]; right_mouth_x = get(291)[0]
        top_lip_y = get(13)[1]; bottom_lip_y = get(14)[1]
        mouth_w = abs(right_mouth_x - left_mouth_x)
        mouth_h = abs(bottom_lip_y - top_lip_y)

        # brow positions
        brow_left_y = get(70)[1] if len(L) > 70 else get(55)[1]
        brow_right_y = get(300)[1] if len(L) > 300 else get(285)[1]
        brow_sep = abs(get(70)[0] - get(300)[0]) if len(L) > 300 else 0.12

        # heuristics
        if mouth_w > 0.065 and mouth_h > 0.02:
            return "Happy"
        if mouth_h < 0.02 and top_lip_y > get(1)[1] + 0.02:
            return "Sad"
        if (brow_left_y < get(1)[1] + 0.02 and brow_right_y < get(1)[1] + 0.02) and brow_sep < 0.12:
            return "Angry"
        if abs(brow_left_y - brow_right_y) > 0.02:
            return "Confused"
        return "Neutral"
