# replace_interp_with_numpy.py
import os, importlib.util, shutil

spec = importlib.util.find_spec('scikitplot')
if spec is None or not spec.submodule_search_locations:
    print("scikitplot not found; aborting.")
    raise SystemExit(1)
pkg_dir = spec.submodule_search_locations[0]
print("scikitplot package directory:", pkg_dir)

targets = [
    os.path.join(pkg_dir, "metrics.py"),
    os.path.join(pkg_dir, "plotters.py"),
]

for path in targets:
    if not os.path.exists(path):
        print("File not found:", path)
        continue
    # backup again just in case
    bak = path + ".restored.bak"
    if not os.path.exists(bak):
        shutil.copy2(path, bak)
        print("Created backup:", bak)
    with open(path, "r", encoding="utf-8") as f:
        src = f.read()
    if "from scipy import interp" in src:
        src2 = src.replace("from scipy import interp", "from numpy import interp")
        with open(path, "w", encoding="utf-8") as f:
            f.write(src2)
        print("Replaced import in:", path)
    else:
        print("No exact 'from scipy import interp' found in:", path)
print("Done.")
