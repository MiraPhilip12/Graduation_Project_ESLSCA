import cv2

print("Testing camera...")

# Try indices 0, 1, 2
camera_index = None
for i in range(3):
    cap = cv2.VideoCapture(i)
    if cap.isOpened():
        print(f"Camera works at index {i}")
        camera_index = i
        cap.release()
        break

if camera_index is None:
    print("No camera detected. Check macOS permissions.")
    exit()

cap = cv2.VideoCapture(camera_index)
cv2.namedWindow("Camera Test", cv2.WINDOW_NORMAL | cv2.WINDOW_GUI_NORMAL)
cv2.resizeWindow("Camera Test", 800, 600)

while True:
    ret, frame = cap.read()
    if not ret:
        print("Cannot read frame. Retrying...")
        continue

    cv2.imshow("Camera Test", frame)
    if cv2.waitKey(10) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
