# trainer/train_emotion.py
"""
Train a classifier on trainer/dataset/landmarks.csv using PyCaret.
Saves best model to ../models/emotion_model.pkl
Usage:
    cd handball_system/trainer
    python train_emotion.py
"""
import os
import pandas as pd
import joblib
from pycaret.classification import setup, compare_models, finalize_model, save_model, load_model, get_config

DATA_CSV = 'trainer/dataset/landmarks.csv'
OUT_MODEL = '../models/emotion_model.pkl'

def load_df(path):
    df = pd.read_csv(path, header=None)
    # ensure label column exists
    if df.shape[1] < 2:
        raise ValueError("Dataset seems wrong: fewer than 2 columns.")
    # rename columns: first is 'label', rest f1..fn
    cols = ['label'] + [f'f{i}' for i in range(1, df.shape[1])]
    df.columns = cols
    return df

def main():
    print("Loading dataset:", DATA_CSV)
    df = load_df(DATA_CSV)
    print("Rows:", len(df), "Classes:", df['label'].unique())

    # shuffle
    df = df.sample(frac=1.0, random_state=42).reset_index(drop=True)

    # Use a subset of classifiers that are fast & reliable
    clf_include = ['rf', 'lightgbm', 'xgboost', 'et']  # random forest, lgbm, xgb, extra trees

    print("Setting up PyCaret (this may print INFO lines)...")
    exp = setup(data=df, target='label', session_id=42, silent=True, verbose=False, preprocess=True, normalize=True)

    print("Comparing models (this may take a few minutes depending on dataset size)...")
    best = compare_models(include=clf_include, n_select=1, fold=5, sort='Accuracy', turbo=False)
    print("Selected model:", best)

    print("Finalizing model...")
    final = finalize_model(best)

    # ensure models dir exists
    os.makedirs(os.path.dirname(OUT_MODEL), exist_ok=True)
    print("Saving model to", OUT_MODEL)
    joblib.dump(final, OUT_MODEL)
    print("Model saved. Done.")

if __name__ == "__main__":
    main()
