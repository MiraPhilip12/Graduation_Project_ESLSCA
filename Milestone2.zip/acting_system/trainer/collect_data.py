# ensure parent folder (project root) is on Python path so imports like `import detector` work
import sys, os
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import csv
import os
import argparse
import time
import cv2
import numpy as np
from detector import ThreadedVideoCapture, MediapipeWrapper

parser = argparse.ArgumentParser()
parser.add_argument('--label', required=True, help='Label for this capture (e.g., happy, wave)')
parser.add_argument('--out', default='trainer/dataset/landmarks.csv')
parser.add_argument('--count', type=int, default=200)
parser.add_argument('--cam', type=int, default=0, help='Camera index to use (default 0)')
parser.add_argument('--skip', type=int, default=0, help='Skip initial frames (warm-up)')
args = parser.parse_args()

os.makedirs(os.path.dirname(args.out), exist_ok=True)

cam = ThreadedVideoCapture(args.cam, width=640, height=480)
mpwrap = MediapipeWrapper()
collected = 0
written = 0
start_time = time.time()

# helper to flatten landmarks to fixed lengths (face 468, hands 21, pose 33)
def flatten_landmarks(arr, n=0):
    if arr is None:
        return [0.0]*(n*3)
    arr = np.asarray(arr).reshape(-1,3)
    out = arr.flatten().tolist()
    if len(out) < n*3:
        out += [0.0]*(n*3 - len(out))
    return out

print(f"Starting collection for label='{args.label}', target={args.count} samples.")
with open(args.out, 'a', newline='') as csvfile:
    writer = csv.writer(csvfile)
    # optional header if file new
    if os.path.getsize(args.out) == 0:
        # header omitted for compactness (we'll treat first col as label)
        pass

    while collected < args.count:
        frame = cam.read_latest()
        if frame is None:
            time.sleep(0.01)
            continue

        # warm-up skipping
        if written < args.skip:
            written += 1
            continue

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        data, annotated = mpwrap.process(rgb)

        # build feature vector
        features = []
        features += flatten_landmarks(data.get("face_landmarks"), n=468)
        features += flatten_landmarks(data.get("left_hand"), n=21)
        features += flatten_landmarks(data.get("right_hand"), n=21)
        features += flatten_landmarks(data.get("pose"), n=33)

        # write labelled row
        writer.writerow([args.label] + features)
        collected += 1

        # show annotated window so you can see detection
        try:
            bgr = cv2.cvtColor(annotated, cv2.COLOR_RGB2BGR)
            cv2.putText(bgr, f"{args.label} {collected}/{args.count}", (10,30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)
            cv2.imshow('collect (press q to abort)', bgr)
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                print("Aborted by user.")
                break
        except Exception:
            pass

print(f"Collected {collected} samples to {args.out} in {time.time()-start_time:.1f}s")
cam.stop()
try:
    cv2.destroyAllWindows()
except Exception:
    pass
