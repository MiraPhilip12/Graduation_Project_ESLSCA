# audio_vad.py
import webrtcvad
import sounddevice as sd
import numpy as np
import threading
import time
from collections import deque

class VADStream:
    """
    Robust VAD stream:
    - captures at device native samplerate (capture_sr)
    - resamples to vad_sr (16000) before feeding webrtcvad
    - uses a sliding window of recent VAD bools to compute is_speaking
    """
    def __init__(self, aggressiveness=2, vad_sr=16000, frame_ms=30, buffer_seconds=1.0):
        self.vad = webrtcvad.Vad(aggressiveness)
        self.vad_sr = int(vad_sr)
        self.frame_ms = int(frame_ms)
        self.vad_frame_size = int(self.vad_sr * self.frame_ms / 1000)  # samples for vad frame (e.g., 480 samples)
        self.buffer_frames = int(buffer_seconds * 1000 / frame_ms)
        self.recent = deque(maxlen=self.buffer_frames)

        # discover default input device and its native rate
        try:
            dev = sd.default.device
            if isinstance(dev, (list, tuple)):
                dev_idx = dev[0]
            else:
                dev_idx = dev
            if dev_idx is None or dev_idx < 0:
                # find first input-capable device
                devices = sd.query_devices()
                dev_idx = next((i for i,d in enumerate(devices) if d.get('max_input_channels',0)>0), None)
            dev_info = sd.query_devices(dev_idx)
            self.capture_sr = int(dev_info.get('default_samplerate', 48000))
            self.device = dev_idx
        except Exception:
            # fallback
            self.capture_sr = 48000
            self.device = None

        # internal buffer to accumulate int16 samples at capture_sr
        self._buf_lock = threading.Lock()
        self._buf = np.zeros(0, dtype=np.int16)

        self.is_speaking = False
        self._stop_event = threading.Event()
        self._thread = None
        self._stream = None

    def _resample_to_vad(self, samples):
        """
        Resample a 1-D int16 numpy array `samples` from capture_sr -> vad_sr using linear interpolation.
        Returns int16 samples at vad_sr.
        """
        if self.capture_sr == self.vad_sr:
            return samples
        if len(samples) == 0:
            return samples
        # create sample indices
        duration = len(samples) / self.capture_sr
        if duration <= 0:
            return np.array([], dtype=np.int16)
        num_target = int(round(duration * self.vad_sr))
        if num_target <= 0:
            return np.array([], dtype=np.int16)
        # use float for interpolation
        src_x = np.linspace(0, 1, len(samples))
        tgt_x = np.linspace(0, 1, num_target)
        try:
            # normalize to float for interp, then scale back
            samples_f = samples.astype(np.float32)
            resampled_f = np.interp(tgt_x, src_x, samples_f)
            resampled = np.clip(np.round(resampled_f), -32768, 32767).astype(np.int16)
            return resampled
        except Exception:
            # fallback: naive decimation/upsampling
            idx = (np.linspace(0, len(samples)-1, num_target)).astype(int)
            return samples[idx].astype(np.int16)

    def _process_buffer(self):
        """
        Runs in background thread: consume capture buffer, create VAD-sized frames at vad_sr,
        call vad.is_speech for each frame and append bool decisions to recent deque.
        """
        # compute capture frame size equivalent to vad frame duration
        capture_frame_size = int(self.capture_sr * self.frame_ms / 1000)
        while not self._stop_event.is_set():
            try:
                with self._buf_lock:
                    available = len(self._buf)
                if available < capture_frame_size:
                    time.sleep(0.01)
                    continue
                # take capture_frame_size samples (int16) from buffer
                with self._buf_lock:
                    chunk = self._buf[:capture_frame_size].copy()
                    self._buf = self._buf[capture_frame_size:]
                # resample chunk to vad_sr
                vad_samples = self._resample_to_vad(chunk)
                # vad_samples may be shorter/longer; we need to split into vad_frame_size chunks
                if len(vad_samples) < self.vad_frame_size:
                    # accumulate more (put back to buffer) — but simpler: skip this small chunk
                    continue
                # iterate vad frames
                num_vad_frames = len(vad_samples) // self.vad_frame_size
                for i in range(num_vad_frames):
                    f = vad_samples[i*self.vad_frame_size:(i+1)*self.vad_frame_size]
                    try:
                        is_speech = self.vad.is_speech(f.tobytes(), sample_rate=self.vad_sr)
                    except Exception:
                        is_speech = False
                    self.recent.append(is_speech)
                # update speaking flag (threshold)
                if len(self.recent) == 0:
                    self.is_speaking = False
                else:
                    ratio = sum(1 for v in self.recent if v) / len(self.recent)
                    self.is_speaking = ratio > 0.3
            except Exception:
                time.sleep(0.01)

    def _audio_callback(self, indata, frames, time_info, status):
        """
        sounddevice callback receives float32 in [-1,1] typically.
        Convert to int16 and append to buffer.
        """
        if status:
            # non-fatal warnings (overruns) reported here
            pass
        try:
            mono = indata if indata.ndim == 1 else indata.mean(axis=1)
            int16 = (mono * 32767).astype(np.int16)
            with self._buf_lock:
                self._buf = np.concatenate([self._buf, int16])
                # cap buffer size to avoid memory growth
                max_samples = int(self.capture_sr * 5)  # keep last 5 seconds max
                if len(self._buf) > max_samples:
                    self._buf = self._buf[-max_samples:]
        except Exception:
            pass

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        try:
            # open stream at capture_sr with mono channel
            self._stream = sd.InputStream(samplerate=self.capture_sr, device=self.device, channels=1, dtype='float32', callback=self._audio_callback)
            self._stream.start()
        except Exception as e:
            raise RuntimeError(f"Failed to start audio stream: {e}")
        self._thread = threading.Thread(target=self._process_buffer, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop_event.set()
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
        if self._thread:
            self._thread.join(timeout=1.0)
