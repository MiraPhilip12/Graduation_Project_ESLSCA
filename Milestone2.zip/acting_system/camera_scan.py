# camera_scan.py
"""
Scan camera indices 0..6 and report which indices can produce a valid frame.
Usage:
    python camera_scan.py
"""
import cv2
import time

def try_cam(idx, timeout=1.0):
    # Use DirectShow backend on Windows for more reliable behavior
    try:
        cap = cv2.VideoCapture(idx, cv2.CAP_DSHOW)
    except Exception:
        cap = cv2.VideoCapture(idx)
    if not cap.isOpened():
        return False, None
    start = time.time()
    ok, frame = False, None
    while time.time() - start < timeout:
        ok, frame = cap.read()
        if ok and frame is not None:
            break
        time.sleep(0.05)
    cap.release()
    if ok and frame is not None:
        return True, frame.shape
    return False, None

def main():
    print("Scanning camera indices 0..6 (this may take ~5-10s)...")
    found = []
    for i in range(0, 7):
        ok, shape = try_cam(i)
        print(f"Index {i}: {'OK' if ok else 'NO'}", f"shape={shape}" if shape else "")
        if ok:
            found.append((i, shape))
    print("-" * 40)
    if found:
        print("Usable camera indices found:")
        for idx, shape in found:
            print(f" -> {idx}  (shape {shape})")
        print("\nUse the lowest index above (e.g., ThreadedVideoCapture(<index>)) in detector tests.")
    else:
        print("No usable camera indices detected. Troubleshooting tips:")
        print("  1) Close apps that might use the camera (Teams, Zoom, browser tabs).")
        print("  2) Open the Windows Camera app to check the feed.")
        print("  3) Check Windows Settings → Privacy & security → Camera (allow access).")
        print("  4) If external USB camera, try reconnecting or a different port.")
        print("  5) In Device Manager, check camera drivers and enable device if disabled.")
    print("-" * 40)

if __name__ == "__main__":
    main()
