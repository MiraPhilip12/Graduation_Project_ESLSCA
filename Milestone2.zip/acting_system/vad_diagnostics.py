# vad_diagnostics.py
# Diagnostic script:
# - lists audio devices
# - chooses a supported SR (8000/16000/32000/48000)
# - records ~2s from the default/first input device
# - prints RMS/peak & runs WebRTC VAD over recorded frames
# Usage: python vad_diagnostics.py

import sounddevice as sd
import numpy as np
import webrtcvad
import math
import sys

SUPPORTED_SR = [8000, 16000, 32000, 48000]

def list_devices():
    print("=== sounddevice query_devices() ===")
    try:
        devices = sd.query_devices()
        default_device = sd.default.device
    except Exception as e:
        print("Failed to query devices:", e)
        return None, None

    for i, d in enumerate(devices):
        io = []
        if d.get('max_input_channels', 0) > 0:
            io.append("INPUT")
        if d.get('max_output_channels', 0) > 0:
            io.append("OUTPUT")
        tag = ",".join(io) or "N/A"
        print(f"{i}: {d['name']} ({tag}) default_samplerate={d.get('default_samplerate')}, max_in={d.get('max_input_channels')}")
    print("Default device index (sounddevice):", default_device)
    return devices, default_device

def choose_sample_rate(dev_info):
    default_sr = int(dev_info.get('default_samplerate', 16000))
    nearest = min(SUPPORTED_SR, key=lambda x: abs(x - default_sr))
    return nearest

def record_and_test(sample_rate=16000, duration=2.0, device=None):
    print(f"\nRecording {duration}s at {sample_rate} Hz (device={device})...")
    try:
        # record as int16 directly (sounddevice will deliver int16 if dtype specified)
        rec = sd.rec(int(duration * sample_rate), samplerate=sample_rate, channels=1, dtype='int16', device=device)
        sd.wait()
    except Exception as e:
        print("Recording failed:", e)
        return None

    audio = rec.flatten()
    print("Recorded samples:", len(audio))
    # amplitude stats
    abs_vals = np.abs(audio.astype(np.int32))
    rms = math.sqrt(np.mean((audio.astype(np.float32)/32768.0)**2))
    peak = int(abs_vals.max())
    mean_amp = float(abs_vals.mean())
    print(f"RMS (normalized): {rms:.6f}, peak: {peak}, mean_abs: {mean_amp:.1f}")

    # run VAD on frames
    vad = webrtcvad.Vad(2)
    frame_ms = 30
    frame_size = int(sample_rate * frame_ms / 1000)
    total_frames = len(audio) // frame_size
    print("Frame size (samples):", frame_size, "Total frames:", total_frames)
    speech_frames = 0
    for i in range(total_frames):
        frame = audio[i*frame_size:(i+1)*frame_size]
        if len(frame) != frame_size:
            continue
        try:
            is_speech = vad.is_speech(frame.tobytes(), sample_rate=sample_rate)
        except Exception as e:
            print("VAD error on frame:", e)
            is_speech = False
        if is_speech:
            speech_frames += 1
    print(f"VAD detected speech frames: {speech_frames}/{total_frames} ({(speech_frames/total_frames*100) if total_frames>0 else 0:.1f}%)")
    return audio, sample_rate

if __name__ == "__main__":
    devices, default_device = list_devices()
    if devices is None:
        sys.exit(1)

    # pick input device index
    device_index = None
    if isinstance(default_device, (list, tuple)):
        device_index = default_device[0]
    elif isinstance(default_device, int):
        device_index = default_device

    if device_index is None or device_index < 0:
        for i, d in enumerate(devices):
            if d.get('max_input_channels', 0) > 0:
                device_index = i
                break

    if device_index is None:
        print("No input device found.")
        sys.exit(1)

    dev_info = devices[device_index]
    print("\nUsing device index:", device_index, "name:", dev_info['name'])
    chosen_sr = choose_sample_rate(dev_info)
    print("Device default samplerate:", dev_info.get('default_samplerate'), "-> choosing supported SR:", chosen_sr)

    audio, sr = record_and_test(chosen_sr, duration=2.0, device=device_index)

    if audio is None:
        try:
            fallback_sr = int(dev_info.get('default_samplerate', 44100))
            print("\nRetrying with device default samplerate:", fallback_sr)
            audio, sr = record_and_test(fallback_sr, duration=2.0, device=device_index)
        except Exception as e:
            print("Fallback recording failed:", e)
            sys.exit(1)

    print("\nDiagnostic finished. If RMS is near zero or VAD speech frames are 0, check microphone, permissions, and device settings.")
