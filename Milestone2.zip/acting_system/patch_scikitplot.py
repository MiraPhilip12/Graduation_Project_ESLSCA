# patch_scikitplot.py
import importlib.util, os, shutil, sys

spec = importlib.util.find_spec('scikitplot')
if spec is None or not spec.submodule_search_locations:
    print("scikitplot package not found in this Python environment.")
    sys.exit(1)

pkg_dir = spec.submodule_search_locations[0]
metrics_path = os.path.join(pkg_dir, 'metrics.py')

if not os.path.exists(metrics_path):
    print("metrics.py not found at", metrics_path)
    sys.exit(1)

bak = metrics_path + '.bak'
if not os.path.exists(bak):
    shutil.copy2(metrics_path, bak)
    print("Backup created:", bak)
else:
    print("Backup already exists:", bak)

with open(metrics_path, 'r', encoding='utf-8') as f:
    src = f.read()

old = "from scipy import interp"
if old in src:
    new = (
        "try:\n"
        "    # older scipy provided interp; prefer that when available\n"
        "    from scipy import interp\n"
        "except Exception:\n"
        "    # newer scipy removed interp — fall back to numpy.interp\n"
        "    from numpy import interp\n"
    )
    src2 = src.replace(old, new, 1)
    with open(metrics_path, 'w', encoding='utf-8') as f:
        f.write(src2)
    print("Patched metrics.py to use numpy.interp fallback.")
else:
    print("metrics.py did not contain the exact import line; no change made.")
    # optionally show first lines
    print("First 3 lines of file:")
    print("\n".join(src.splitlines()[:10]))
