# fix_interp_indent.py
import os

paths = [
    r"C:\Users\rabbit\miniconda3\envs\handball-env\lib\site-packages\scikitplot\metrics.py",
    r"C:\Users\rabbit\miniconda3\envs\handball-env\lib\site-packages\scikitplot\plotters.py",
]

fixed_count = 0
for path in paths:
    if not os.path.exists(path):
        print("File not found:", path)
        continue
    with open(path, "r", encoding="utf-8") as f:
        src = f.read()

    # Replace broken block with properly indented one
    new_import = (
        "try:\n"
        "    from scipy import interp\n"
        "except Exception:\n"
        "    from numpy import interp\n"
    )

    src2 = []
    for line in src.splitlines():
        if "from scipy import interp" in line:
            # Detect current indentation
            indent = line[:len(line) - len(line.lstrip())]
            # Apply the same indent to all lines of new_import
            block = "\n".join(indent + l for l in new_import.splitlines())
            src2.append(block)
        else:
            src2.append(line)
    new_src = "\n".join(src2)

    with open(path, "w", encoding="utf-8") as f:
        f.write(new_src)
    fixed_count += 1
    print("Fixed indentation in:", path)

print(f"Repaired {fixed_count} files.")
