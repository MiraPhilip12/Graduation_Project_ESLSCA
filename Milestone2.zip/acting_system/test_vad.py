# test_vad.py
import webrtcvad
import sounddevice as sd
import numpy as np

# initialize VAD: aggressiveness 0–3 (higher = more sensitive to speech)
vad = webrtcvad.Vad(2)

duration = 3  # seconds to record
sample_rate = 16000  # WebRTC VAD works best at 16 kHz
frame_duration = 30  # ms per frame
frame_size = int(sample_rate * frame_duration / 1000)

print("🎤 Speak for a few seconds after this line — testing VAD...")
audio = sd.rec(int(duration * sample_rate), samplerate=sample_rate, channels=1, dtype='int16')
sd.wait()

# flatten to mono
audio = audio.flatten()

speech_frames = 0
total_frames = len(audio) // frame_size

for i in range(total_frames):
    frame = audio[i * frame_size:(i + 1) * frame_size]
    if len(frame) < frame_size:
        continue
    if vad.is_speech(frame.tobytes(), sample_rate):
        speech_frames += 1

speech_ratio = speech_frames / total_frames

print(f"Speech frames detected: {speech_frames}/{total_frames} ({speech_ratio*100:.1f}%)")

if speech_ratio > 0.3:
    print("✅ Speech detected!")
else:
    print("❌ No speech detected or too quiet.")
