import sys
import cv2
import numpy as np
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QImage, QPixmap, QFont
from PyQt5.QtCore import Qt, QTimer
from worker import ActingSystemWorker

class ActingSystemApp(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Acting System")
        self.setStyleSheet("background-color: #F4F4F4;")  # Modern light gray

        self.worker = ActingSystemWorker()
        self.capture = None
        self.running = False

        self.build_ui()
        self.showMaximized()

    # -----------------------------------------------------
    # UI LAYOUT
    # -----------------------------------------------------
    def build_ui(self):
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(25)

        # ========== LEFT SIDEBAR ==========
        sidebar = QVBoxLayout()
        sidebar.setSpacing(18)

        section_font = QFont("Helvetica", 17, QFont.Bold)
        item_font = QFont("Helvetica", 15)

        # FACE SECTION
        face_header = QLabel("FACE")
        face_header.setFont(section_font)
        face_header.setStyleSheet("color: #2E2A27;")
        sidebar.addWidget(face_header)

        self.emotion_lbl = self.make_label(item_font)
        self.mouth_lbl = self.make_label(item_font)
        self.eyes_lbl = self.make_label(item_font)
        self.brows_lbl = self.make_label(item_font)

        sidebar.addWidget(self.emotion_lbl)
        sidebar.addWidget(self.mouth_lbl)
        sidebar.addWidget(self.eyes_lbl)
        sidebar.addWidget(self.brows_lbl)

        sidebar.addSpacing(20)

        # BODY SECTION
        body_header = QLabel("BODY")
        body_header.setFont(section_font)
        body_header.setStyleSheet("color: #2E2A27;")
        sidebar.addWidget(body_header)

        self.posture_lbl = self.make_label(item_font)
        self.arms_lbl = self.make_label(item_font)

        sidebar.addWidget(self.posture_lbl)
        sidebar.addWidget(self.arms_lbl)

        sidebar.addSpacing(20)

        # HANDS SECTION
        hands_header = QLabel("HANDS")
        hands_header.setFont(section_font)
        hands_header.setStyleSheet("color: #2E2A27;")
        sidebar.addWidget(hands_header)

        self.left_hand_lbl = self.make_label(item_font)
        self.right_hand_lbl = self.make_label(item_font)
        self.waving_lbl = self.make_label(item_font)

        sidebar.addWidget(self.left_hand_lbl)
        sidebar.addWidget(self.right_hand_lbl)
        sidebar.addWidget(self.waving_lbl)

        sidebar.addSpacing(20)

        # OTHER
        other_header = QLabel("OTHER")
        other_header.setFont(section_font)
        other_header.setStyleSheet("color: #2E2A27;")
        sidebar.addWidget(other_header)

        self.actor_status_lbl = self.make_label(item_font)
        self.people_count_lbl = self.make_label(item_font)

        sidebar.addWidget(self.actor_status_lbl)
        sidebar.addWidget(self.people_count_lbl)

        sidebar.addStretch()
        main_layout.addLayout(sidebar, 1)

        # ========== VIDEO FRAME ==========
        self.video_label = QLabel()
        self.video_label.setStyleSheet("background-color: black; border-radius: 10px;")
        self.video_label.setFixedSize(960, 720)
        main_layout.addWidget(self.video_label, 3, alignment=Qt.AlignCenter)

        # Timer
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)

    # -----------------------------------------------------
    def make_label(self, font):
        lbl = QLabel("-")
        lbl.setFont(font)
        lbl.setStyleSheet("color: #2E2A27;")
        return lbl

    # -----------------------------------------------------
    def start_camera(self):
        if self.running:
            return
        self.capture = cv2.VideoCapture(0)
        if not self.capture.isOpened():
            print("Error: Camera not found.")
            return
        self.running = True
        self.timer.start(15)

    # -----------------------------------------------------
    def load_videos(self):
        # Load the two videos: good actor and bad actor
        good_video_path = "/Users/fatmamilad/Desktop/Acting System.1/acting_system/videos/WhatsApp Video 2025-11-14 at 11.41.35.mp4"
        bad_video_path = "/Users/fatmamilad/Desktop/Acting System.1/acting_system/videos/WhatsApp Video 2025-11-14 at 11.41.35 (2).mp4"

        cap_good = cv2.VideoCapture(good_video_path)
        cap_bad = cv2.VideoCapture(bad_video_path)

        if not cap_good.isOpened() or not cap_bad.isOpened():
            print("Error: One of the videos cannot be opened.")
            return

        self.capture = (cap_good, cap_bad)
        self.running = True
        self.timer.start(30)  # slower frame for videos

    # -----------------------------------------------------
    def update_frame(self):
        if not self.running:
            return

        annotated = None
        actors_to_update = None

        # Camera mode
        if isinstance(self.capture, cv2.VideoCapture):
            ret, frame = self.capture.read()
            if not ret:
                self.capture.release()
                self.running = False
                return
            frame = cv2.resize(frame, (960, 720))
            actors = self.worker.process_frame(frame)
            annotated = self.worker.render(frame.copy(), actors)
            actors_to_update = actors

        # Video mode
        elif isinstance(self.capture, tuple):
            cap_good, cap_bad = self.capture

            ret1, frame1 = cap_good.read()
            ret2, frame2 = cap_bad.read()

            # Restart videos if ended
            if not ret1:
                cap_good.set(cv2.CAP_PROP_POS_FRAMES, 0)
                ret1, frame1 = cap_good.read()
            if not ret2:
                cap_bad.set(cv2.CAP_PROP_POS_FRAMES, 0)
                ret2, frame2 = cap_bad.read()

            # Ensure frame exists
            if not ret1:
                frame1 = np.zeros((720, 480, 3), dtype=np.uint8)
            if not ret2:
                frame2 = np.zeros((720, 480, 3), dtype=np.uint8)

            # Resize for stacking
            frame1 = cv2.resize(frame1, (480, 720))
            frame2 = cv2.resize(frame2, (480, 720))

            actors1 = self.worker.process_frame(frame1)
            actors2 = self.worker.process_frame(frame2)

            annotated1 = self.worker.render(frame1.copy(), actors1)
            annotated2 = self.worker.render(frame2.copy(), actors2)

            annotated = np.hstack([annotated1, annotated2])
            actors_to_update = actors1  # Update sidebar with first video

            # Top-left labels for each video
            cv2.putText(annotated, "Good Actor - Confident", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
            cv2.putText(annotated, "Bad Actor - Leaning", (500, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)

        # Display
        if annotated is not None:
            rgb = cv2.cvtColor(annotated, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb.shape
            img = QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888)
            self.video_label.setPixmap(QPixmap.fromImage(img))

        # Update sidebar
        if actors_to_update and len(actors_to_update) > 0:
            pid = list(actors_to_update.keys())[0]
            self.update_sidebar(actors_to_update[pid], len(actors_to_update))

    # -----------------------------------------------------
    def update_sidebar(self, info, count):
        self.emotion_lbl.setText(f"Emotion: {info['emotion']}")
        self.mouth_lbl.setText(f"Mouth: {info['mouth_state']}")
        self.eyes_lbl.setText(f"Eyes: {info['eyes']}")
        self.brows_lbl.setText(f"Brows: {info['brows']}")
        self.posture_lbl.setText(f"Posture: {info['posture']}")
        self.arms_lbl.setText(f"Arms: {info['arms_state']}")
        self.left_hand_lbl.setText(f"Left Hand: {info['hands']['left']}")
        self.right_hand_lbl.setText(f"Right Hand: {info['hands']['right']}")
        self.waving_lbl.setText(f"Waving: {'Yes' if info['waving'] else 'No'}")
        self.actor_status_lbl.setText(f"Actor Status: {info['actor_quality']}")
        self.people_count_lbl.setText(f"People in Frame: {count}")


# ============================================================
# TERMINAL MENU
# ============================================================
if __name__ == "__main__":
    while True:
        print("\nSelect Mode:")
        print("1 - Camera")
        print("2 - Videos (Good + Bad Actor)")
        print("3 - Quit")
        choice = input("Enter choice: ")

        if choice == "1":
            app = QApplication(sys.argv)
            window = ActingSystemApp()
            window.start_camera()
            window.show()
            sys.exit(app.exec_())
        elif choice == "2":
            app = QApplication(sys.argv)
            window = ActingSystemApp()
            window.load_videos()
            window.show()
            sys.exit(app.exec_())
        elif choice == "3":
            print("Exiting...")
            break
        else:
            print("Invalid choice. Try again.")
