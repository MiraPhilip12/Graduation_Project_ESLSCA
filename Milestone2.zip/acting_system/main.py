import cv2
import time
import os
from worker import ActingSystemWorker
from ui import draw_info_panel

VIDEO_PATHS = [
    "/Users/fatmamilad/Desktop/Acting System.1/acting_system/videos/WhatsApp Video 2025-11-14 at 11.41.35.mp4",
    "/Users/fatmamilad/Desktop/Acting System.1/acting_system/videos/WhatsApp Video 2025-11-14 at 11.41.35 (2).mp4",
]

PROC_WIDTH = 640  # processing width

def terminal_menu():
    while True:
        os.system("cls" if os.name == "nt" else "clear")
        print("===========================================")
        print("   Professional Acting Analysis — Console")
        print("===========================================")
        print("1 — Camera")
        print("2 — Video")
        print("3 — Quit")
        choice = input("\nEnter choice (1/2/3): ").strip()
        if choice == "1":
            return 1, None
        if choice == "2":
            print("\nAvailable videos:")
            for idx, path in enumerate(VIDEO_PATHS):
                print(f"  {idx+1}. {os.path.basename(path)}")
            vid_choice = input("\nEnter video number (or 'b' to go back): ").strip()
            if vid_choice.lower() == 'b':
                continue
            try:
                vid_idx = int(vid_choice) - 1
                if 0 <= vid_idx < len(VIDEO_PATHS):
                    return 2, VIDEO_PATHS[vid_idx]
            except:
                pass
            print("Invalid selection. Press Enter to continue.")
            input()
        if choice == "3":
            print("Goodbye.")
            exit(0)

def draw_overlays(display_frame, detection_results):
    h, w = display_frame.shape[:2]
    for pid, info in detection_results.items():
        label_y = 30 + pid * 20
        text = f"Actor {pid+1}: {info.get('emotion','')}, {info.get('posture','')}"
        cv2.putText(display_frame, text, (12, label_y), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (20,20,20), 4, cv2.LINE_AA)
        cv2.putText(display_frame, text, (12, label_y), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (245,245,245), 1, cv2.LINE_AA)

        face_lms = info.get("face_landmarks", None)
        if face_lms:
            for lm in face_lms:
                x = int(lm[0] * w)
                y = int(lm[1] * h)
                cv2.circle(display_frame, (x, y), 2, (200,180,60), -1)

        pose_lms = info.get("pose_landmarks", None)
        if pose_lms:
            for (a, b) in [(11,13),(13,15),(12,14),(14,16),(11,12),(23,24),(23,25),(24,26)]:
                if a < len(pose_lms) and b < len(pose_lms):
                    xa, ya = int(pose_lms[a][0]*w), int(pose_lms[a][1]*h)
                    xb, yb = int(pose_lms[b][0]*w), int(pose_lms[b][1]*h)
                    cv2.line(display_frame, (xa,ya), (xb,yb), (100,200,100), 2)
            for lm in pose_lms:
                xi, yi = int(lm[0]*w), int(lm[1]*h)
                cv2.circle(display_frame, (xi, yi), 3, (80,160,220), -1)

        hands = info.get("hands_full", [])
        for hand_dict in hands:
            label = hand_dict.get("label", "hand")
            lms = hand_dict.get("landmarks", [])
            color = (180,120,220) if label.lower().startswith("r") else (120,220,180)
            for nx, ny in lms:
                cv2.circle(display_frame, (int(nx*w), int(ny*h)), 3, color, -1)

def run_app(mode, video_path=None):
    worker = ActingSystemWorker()
    cap = None

    if mode == 1:
        for i in range(4):
            cap = cv2.VideoCapture(i)
            if cap.isOpened():
                break
        if not cap or not cap.isOpened():
            print("Cannot open camera.")
            return
    else:
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            print(f"Cannot open video: {video_path}")
            return

    window_name = "Professional Acting System"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window_name, 1400, 840)

    last_print = time.time()
    frame_count = 0
    start_time = time.time()

    while True:
        ret, frame = cap.read()
        if not ret or frame is None:
            if mode == 2:
                cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                continue
            else:
                time.sleep(0.1)
                continue

        orig_h, orig_w = frame.shape[:2]
        scale = PROC_WIDTH / float(orig_w)
        proc_h = int(orig_h * scale)
        proc_frame = cv2.resize(frame, (PROC_WIDTH, proc_h), interpolation=cv2.INTER_LINEAR)

        detection = worker.process_frame(proc_frame)

        display = frame.copy()
        draw_overlays(display, detection)

        canvas = draw_info_panel(display, detection, display.shape[1], display.shape[0], professional=True)
        cv2.imshow(window_name, canvas)

        frame_count += 1
        if time.time() - last_print > 1.0:
            elapsed = time.time() - start_time
            fps = frame_count / elapsed if elapsed > 0 else 0.0
            now = time.strftime("%H:%M:%S")
            print(f"[{now}] FPS: {fps:.1f} | Actors: {len(detection)}")
            for pid, inf in detection.items():
                print(f" - Actor {pid+1}: Emotion={inf.get('emotion')}, Posture={inf.get('posture')}, Mouth={inf.get('mouth_state')}, Hands={inf.get('hands')}, Waving={inf.get('waving')}")
            last_print = time.time()

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    mode, video_path = terminal_menu()
    run_app(mode, video_path)
