# processor.py
import numpy as np
from collections import deque

class PerPersonProcessor:
    def __init__(self):
        self.mouth_hist = {}  # pid -> deque
        self.hand_x_hist_left = {}  # pid -> deque
        self.hand_x_hist_right = {}  # pid -> deque
        self.max_frames = 12

    def update_face(self, pid, mouth_height):
        if pid not in self.mouth_hist:
            self.mouth_hist[pid] = deque(maxlen=self.max_frames)
        self.mouth_hist[pid].append(mouth_height)

        avg = np.mean(self.mouth_hist[pid])
        max_h = np.max(self.mouth_hist[pid])

        talking = avg > 0.028
        shouting = max_h > 0.055

        return talking, shouting

    def detect_waving(self, pid, left_x, right_x):
        if pid not in self.hand_x_hist_left:
            self.hand_x_hist_left[pid] = deque(maxlen=self.max_frames)
        if pid not in self.hand_x_hist_right:
            self.hand_x_hist_right[pid] = deque(maxlen=self.max_frames)

        waving_detected = False

        # Left hand
        if left_x is not None:
            self.hand_x_hist_left[pid].append(left_x)
            if len(self.hand_x_hist_left[pid]) > 5:
                arr = np.array(self.hand_x_hist_left[pid])
                if arr.max() - arr.min() > 0.045:
                    waving_detected = True

        # Right hand
        if right_x is not None:
            self.hand_x_hist_right[pid].append(right_x)
            if len(self.hand_x_hist_right[pid]) > 5:
                arr = np.array(self.hand_x_hist_right[pid])
                if arr.max() - arr.min() > 0.045:
                    waving_detected = True

        return waving_detected
