# processor.py
from collections import deque

TALK_WINDOW = 8
HAND_WAVE_HISTORY = 12
WAVE_SPEED_THRESH = 0.02  # normalized delta threshold

class PerPersonProcessor:
    def __init__(self):
        self.mouth_hist = {}    # pid -> deque of mouth_h normalized
        self.left_hist = {}     # pid -> deque of left hand x
        self.right_hist = {}    # pid -> deque of right hand x

    def update_face(self, pid, mouth_h):
        h = self.mouth_hist.setdefault(pid, deque(maxlen=TALK_WINDOW))
        h.append(mouth_h)
        if len(h) >= 3:
            diffs = [abs(h[i+1]-h[i]) for i in range(len(h)-1)]
            avg = sum(diffs)/len(diffs)
            talking = avg > 0.002
            shouting = avg > 0.02
            return talking, shouting
        return False, False

    def update_hand_history(self, histmap, pid, xpos):
        if xpos is None:
            return False
        h = histmap.setdefault(pid, deque(maxlen=HAND_WAVE_HISTORY))
        h.append(xpos)
        if len(h) >= 6:
            dxs = [h[i+1]-h[i] for i in range(len(h)-1)]
            dir_changes = 0
            for i in range(len(dxs)-1):
                if dxs[i]*dxs[i+1] < 0 and (abs(dxs[i]) > WAVE_SPEED_THRESH or abs(dxs[i+1]) > WAVE_SPEED_THRESH):
                    dir_changes += 1
            return dir_changes >= 2
        return False

    def detect_waving(self, pid, left_x, right_x):
        left_wave = self.update_hand_history(self.left_hist, pid, left_x)
        right_wave = self.update_hand_history(self.right_hist, pid, right_x)
        return left_wave or right_wave
