from detectors import FaceDetector, PoseDetector, HandDetector, EmotionDetector
from processor import PerPersonProcessor

class ActingSystemWorker:
    def __init__(self):
        self.face_detector = FaceDetector()
        self.pose_detector = PoseDetector()
        self.hand_detector = HandDetector()
        self.emotion_detector = EmotionDetector()
        self.processor = PerPersonProcessor()

    # --------------------------- FRAME PROCESSING ---------------------------
    def process_frame(self, frame):
        h, w = frame.shape[:2]
        actors = {}

        # ------------------------------- FACE -----------------------------------
        faces = self.face_detector.detect(frame)
        face_centers = []

        for i, face in enumerate(faces):
            pid = i
            L = getattr(face, "landmarks", None)
            if not L:
                continue
            L = L.landmark
            face_lms = [(getattr(lm, "x", 0.5), getattr(lm, "y", 0.5)) for lm in L]

            # emotion
            emo = self.emotion_detector.detect_emotion(face_lms)

            # mouth detection safely
            def safe(l, idx): 
                return l[idx] if idx < len(l) and l[idx] is not None else (0.5,0.5)
            top_lip_y = safe(face_lms, 13)[1]
            bottom_lip_y = safe(face_lms, 14)[1]
            mouth_h = abs(bottom_lip_y - top_lip_y)
            talking, shouting = self.processor.update_face(pid, mouth_h)

            if shouting:
                mouth_state = "Shouting"
            elif talking:
                mouth_state = "Talking"
            else:
                mouth_state = "Open" if mouth_h > 0.035 else "Closed"

            # face center for mapping hands/pose
            cx = sum(p[0] for p in face_lms) / len(face_lms)
            face_centers.append((pid, cx))

            actors[pid] = {
                "face_landmarks": face_lms,
                "pose_landmarks": None,
                "hands_full": [],
                "emotion": emo,
                "posture": "",
                "hands": {"left": "hidden", "right": "hidden"},
                "hand_moves": {"left": "", "right": ""},
                "mouth_state": mouth_state,
                "waving": False,
                "raised": {"left": False, "right": False},
                "crossed": False,
                "eyes": "",
                "brows": ""
            }

        # ------------------------------ HANDS ------------------------------------
        hands = self.hand_detector.detect(frame)
        for hand in hands:
            if not hasattr(hand, "landmarks") or not hand.landmarks:
                continue
            lms = [(getattr(lm, "x", 0.5), getattr(lm, "y", 0.5)) for lm in hand.landmarks.landmark]

            mp_label = getattr(hand, "label", None)
            if mp_label == "Left":
                real_label = "left"
            elif mp_label == "Right":
                real_label = "right"
            else:
                real_label = "unknown"

            # choose nearest face
            avg_x = sum([p[0] for p in lms]) / len(lms) if lms else 0.5
            chosen = 0
            if face_centers:
                best_pid, best_dist = None, 1.0
                for pid, cx in face_centers:
                    d = abs(cx - avg_x)
                    if d < best_dist:
                        best_dist = d
                        best_pid = pid
                chosen = best_pid if best_pid is not None else 0

            # ensure actor slot exists
            actors.setdefault(chosen, {
                "face_landmarks": None,
                "pose_landmarks": None,
                "hands_full": [],
                "emotion": "Neutral",
                "posture": "",
                "hands": {"left": "hidden", "right": "hidden"},
                "hand_moves": {"left": "", "right": ""},
                "mouth_state": "",
                "waving": False,
                "raised": {"left": False, "right": False},
                "crossed": False,
                "eyes": "",
                "brows": ""
            })

            actors[chosen]["hands_full"].append({
                "label": real_label.capitalize(),
                "landmarks": lms
            })

            if real_label in ["left", "right"]:
                actors[chosen]["hands"][real_label] = "visible"
            else:
                face_cx = next((cx for pid, cx in face_centers if pid == chosen), 0.5)
                real_label = "left" if avg_x < face_cx else "right"
                actors[chosen]["hands"][real_label] = "visible"

            # waving detection
            try:
                is_waving = self.processor.detect_waving(chosen, avg_x, real_label)
                if is_waving:
                    actors[chosen]["waving"] = True
            except:
                pass

            # store hand movement for UI
            try:
                move = self.processor.detect_hand_movement(chosen, real_label, lms)
                actors[chosen]["hand_moves"][real_label] = move
            except:
                actors[chosen]["hand_moves"][real_label] = ""

        # ------------------------------ POSE -------------------------------------
        poses = self.pose_detector.detect(frame)
        for i, pose in enumerate(poses):
            pid = i
            if not hasattr(pose, "landmarks") or not pose.landmarks:
                continue

            lms = [(getattr(lm, "x", 0.5), getattr(lm, "y", 0.5)) for lm in pose.landmarks.landmark]
            actors.setdefault(pid, {
                "face_landmarks": None,
                "hands_full": [],
                "pose_landmarks": None,
                "emotion": "Neutral",
                "posture": "",
                "hands": {"left": "hidden", "right": "hidden"},
                "hand_moves": {"left": "", "right": ""},
                "mouth_state": "",
                "waving": False,
                "raised": {"left": False, "right": False},
                "crossed": False,
                "eyes": "",
                "brows": ""
            })
            actors[pid]["pose_landmarks"] = lms

            def safe(i, default=(0.5,0.5)):
                return lms[i] if i < len(lms) and lms[i] is not None else default

            # -------------------- Posture using shoulders, hips, knees --------------------
            sh_y = (safe(11)[1] + safe(12)[1]) / 2
            hip_y = (safe(23)[1] + safe(24)[1]) / 2
            knee_y = (safe(25)[1] + safe(26)[1]) / 2

            torso_height = hip_y - sh_y
            leg_height = knee_y - hip_y

            if torso_height < 0.15:
                posture = "Sitting"
            elif torso_height < 0.35:
                posture = "Leaning"
            else:
                posture = "Standing"

            actors[pid]["posture"] = posture

            # raised hands
            lw = safe(15)
            rw = safe(16)
            ls = safe(11)
            rs = safe(12)

            actors[pid]["raised"]["left"] = lw[1] < ls[1] - 0.02 if lw and ls else False
            actors[pid]["raised"]["right"] = rw[1] < rs[1] - 0.02 if rw and rs else False

            left_cross = lw[0] > safe(12)[0] if lw else False
            right_cross = rw[0] < safe(11)[0] if rw else False
            actors[pid]["crossed"] = left_cross and right_cross

        # ----------------------------- EYES & BROWS ------------------------------
        for pid, inf in actors.items():
            L = inf.get("face_landmarks")
            if not L:
                continue

            def g(i, default=(0.5,0.5)):
                return L[i] if i < len(L) and L[i] is not None else default

            # Eye openness
            left_eye_h = abs(g(159)[1] - g(145)[1])
            right_eye_h = abs(g(386)[1] - g(374)[1])
            inf["eyes"] = "Open" if (left_eye_h + right_eye_h)/2 > 0.012 else "Closed"

            # Flexible brows detection
            brow_left_y = g(70)[1]
            brow_right_y = g(300)[1]
            nose_y = g(1)[1]

            left_raised = brow_left_y < nose_y - 0.02
            right_raised = brow_right_y < nose_y - 0.02

            if left_raised and right_raised:
                inf["brows"] = "Raised"
            elif left_raised != right_raised:
                inf["brows"] = "Asymmetric"
            else:
                inf["brows"] = "Symmetric"

            # override emotion if crying
            if inf["mouth_state"]=="Open" and inf["eyes"]=="Closed":
                inf["emotion"] = "Crying"

        return actors
