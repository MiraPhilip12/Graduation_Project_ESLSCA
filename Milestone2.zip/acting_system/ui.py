# ui.py
import cv2
import numpy as np
from datetime import datetime

FONT = cv2.FONT_HERSHEY_SIMPLEX

def put_text_outline(img, text, org, font_scale=0.8, thickness=2, color=(245,245,245), outline=(15,15,15)):
    x,y = org
    cv2.putText(img, text, (x+1, y+1), FONT, font_scale, outline, thickness+2, cv2.LINE_AA)
    cv2.putText(img, text, (x, y), FONT, font_scale, color, thickness, cv2.LINE_AA)

def draw_info_panel(frame, actors_info, width, height, professional=True):
    panel_w = 420
    bg = (32, 35, 40)
    panel = np.full((height, panel_w, 3), bg, dtype=np.uint8)

    title = "acting system audition"
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    put_text_outline(panel, title, (18, 36), font_scale=0.95, thickness=2)
    put_text_outline(panel, now, (18, 62), font_scale=0.55, thickness=1, color=(200,200,200))

    put_text_outline(panel, f"People in frame: {len(actors_info)}", (18, 96), font_scale=0.7, thickness=1)

    start_y = 132
    y = start_y
    per_actor_h = max(140, (height - start_y - 20) // max(1, len(actors_info)))

    for idx,(pid, info) in enumerate(sorted(actors_info.items())):
        header = f"Actor {idx+1}"
        put_text_outline(panel, header, (18, y), font_scale=0.85, thickness=2)
        y += 36
        # list features
        features = [
            ("Emotion", info.get("emotion","Unknown")),
            ("Posture", info.get("posture","Unknown")),
            ("Mouth", info.get("mouth_state","")),
            ("Left hand", info.get("hands",{}).get("left","hidden")),
            ("Right hand", info.get("hands",{}).get("right","hidden")),
            ("Waving", "Yes" if info.get("waving",False) else "No"),
            ("Eyes", info.get("eyes","")),
            ("Brows", info.get("brows","")),
            ("Legs", f"L:{info.get('legs',{}).get('left','')}, R:{info.get('legs',{}).get('right','')}")
        ]
        for label, val in features:
            line = f"{label}: {val}"
            put_text_outline(panel, line, (28, y), font_scale=0.65, thickness=1, color=(225,225,225))
            y += 26
            if y > height - 28:
                break
        y += 14
        if y > height - 28:
            break

    fh, fw = frame.shape[:2]
    if fh != height:
        scale = height / fh
        new_w = max(1, int(fw * scale))
        frame = cv2.resize(frame, (new_w, height), interpolation=cv2.INTER_LINEAR)

    canvas = cv2.hconcat([frame, panel])
    return canvas
