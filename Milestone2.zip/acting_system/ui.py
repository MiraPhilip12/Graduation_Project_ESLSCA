# main.py
import sys
import cv2
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QImage, QPixmap, QFont
from PyQt5.QtCore import Qt, QTimer
from worker import ActingSystemWorker

class ActingSystemApp(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Acting System")
        self.setStyleSheet("background-color: #E8E8E8;")  # light professional gray

        self.worker = ActingSystemWorker()
        self.capture = None
        self.running = False

        self.video_path = None
        self.build_ui()
        self.showMaximized()

    # -----------------------------------------------------
    # UI LAYOUT
    # -----------------------------------------------------
    def build_ui(self):
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(25)

        # ========== LEFT SIDEBAR ==========
        sidebar = QVBoxLayout()
        sidebar.setSpacing(18)
        section_font = QFont("Helvetica", 17, QFont.Bold)
        item_font = QFont("Helvetica", 15)

        # PEOPLE
        people_header = QLabel("People in Frame")
        people_header.setFont(section_font)
        people_header.setStyleSheet("color: #2E2A27;")
        sidebar.addWidget(people_header)
        self.people_count_lbl = QLabel("0")
        self.people_count_lbl.setFont(item_font)
        self.people_count_lbl.setStyleSheet("color:#2E2A27")
        sidebar.addWidget(self.people_count_lbl)

        sidebar.addSpacing(15)

        # EMOTION
        emotion_header = QLabel("Face & Emotion")
        emotion_header.setFont(section_font)
        emotion_header.setStyleSheet("color:#2E2A27;")
        sidebar.addWidget(emotion_header)
        self.emotion_lbl = QLabel("-")
        self.emotion_lbl.setFont(item_font)
        sidebar.addWidget(self.emotion_lbl)
        self.eyes_lbl = QLabel("-")
        self.eyes_lbl.setFont(item_font)
        sidebar.addWidget(self.eyes_lbl)
        self.brows_lbl = QLabel("-")
        self.brows_lbl.setFont(item_font)
        sidebar.addWidget(self.brows_lbl)
        self.mouth_lbl = QLabel("-")
        self.mouth_lbl.setFont(item_font)
        sidebar.addWidget(self.mouth_lbl)

        sidebar.addSpacing(15)

        # GESTURE & HANDS
        gesture_header = QLabel("Gestures & Hands")
        gesture_header.setFont(section_font)
        gesture_header.setStyleSheet("color:#2E2A27;")
        sidebar.addWidget(gesture_header)
        self.posture_lbl = QLabel("-")
        self.posture_lbl.setFont(item_font)
        sidebar.addWidget(self.posture_lbl)
        self.arms_lbl = QLabel("-")
        self.arms_lbl.setFont(item_font)
        sidebar.addWidget(self.arms_lbl)
        self.left_hand_lbl = QLabel("-")
        self.left_hand_lbl.setFont(item_font)
        sidebar.addWidget(self.left_hand_lbl)
        self.right_hand_lbl = QLabel("-")
        self.right_hand_lbl.setFont(item_font)
        sidebar.addWidget(self.right_hand_lbl)
        self.waving_lbl = QLabel("-")
        self.waving_lbl.setFont(item_font)
        sidebar.addWidget(self.waving_lbl)

        sidebar.addSpacing(15)

        # ACTOR STATUS
        status_header = QLabel("Actor Status")
        status_header.setFont(section_font)
        status_header.setStyleSheet("color:#2E2A27;")
        sidebar.addWidget(status_header)
        self.actor_status_lbl = QLabel("-")
        self.actor_status_lbl.setFont(item_font)
        sidebar.addWidget(self.actor_status_lbl)

        sidebar.addStretch()
        main_layout.addLayout(sidebar, 1)

        # ========== VIDEO DISPLAY ==========
        self.video_label = QLabel()
        self.video_label.setStyleSheet("background-color: black; border-radius:5px;")
        self.video_label.setFixedSize(960, 720)
        main_layout.addWidget(self.video_label, 3, alignment=Qt.AlignCenter)

        # ========== BUTTONS ==========
        btns_layout = QHBoxLayout()
        cam_btn = QPushButton("Start Camera")
        cam_btn.setFont(QFont("Helvetica", 15))
        cam_btn.clicked.connect(self.start_camera)
        btns_layout.addWidget(cam_btn)

        vid_btn = QPushButton("Run Video")
        vid_btn.setFont(QFont("Helvetica", 15))
        vid_btn.clicked.connect(self.load_video)
        btns_layout.addWidget(vid_btn)

        quit_btn = QPushButton("Quit")
        quit_btn.setFont(QFont("Helvetica", 15))
        quit_btn.clicked.connect(self.close_app)
        btns_layout.addWidget(quit_btn)

        sidebar.addLayout(btns_layout)

        # Timer for frame updates
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)

    # -----------------------------------------------------
    def start_camera(self):
        if self.running:
            return
        self.capture = cv2.VideoCapture(0)
        self.running = True
        self.timer.start(15)

    # -----------------------------------------------------
    def load_video(self):
        file, _ = QFileDialog.getOpenFileName(self, "Select Video", "", "Video Files (*.mp4 *.avi)")
        if file:
            if self.running:
                self.capture.release()
            self.capture = cv2.VideoCapture(file)
            self.video_path = file
            self.running = True
            self.timer.start(15)

    # -----------------------------------------------------
    def update_frame(self):
        if not self.running:
            return

        ret, frame = self.capture.read()
        if not ret:
            return

        frame = cv2.resize(frame, (960, 720))
        results = self.worker.process_frame(frame)
        annotated = self.worker.render(frame.copy(), results)

        # Overlay top-left actor info for video files
        if self.video_path:
            for pid, info in results.items():
                label = ""
                if "WhatsApp Video 2025-11-14 at 11.41.35.mp4" in self.video_path:
                    label = "Good Actor: Confident & Professional"
                elif "WhatsApp Video 2025-11-14 at 11.41.35 (2).mp4" in self.video_path:
                    label = "Bad Actor: Leaning, Poor Acting"
                if label:
                    cv2.putText(annotated, label, (10, 40), cv2.FONT_HERSHEY_SIMPLEX,
                                1.0, (0, 255, 0) if "Good" in label else (0, 0, 255), 2)
                break  # only top-left first actor

        rgb = cv2.cvtColor(annotated, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        img = QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888)
        self.video_label.setPixmap(QPixmap.fromImage(img))

        # Update sidebar with first actor info
        if results:
            pid = list(results.keys())[0]
            info = results[pid]
            self.update_sidebar(info, len(results))

    # -----------------------------------------------------
    def update_sidebar(self, info, count):
        self.people_count_lbl.setText(str(count))
        self.emotion_lbl.setText(f"Emotion: {info['emotion']}")
        self.eyes_lbl.setText(f"Eyes: {info['eyes']}")
        self.brows_lbl.setText(f"Brows: {info['brows']}")
        self.mouth_lbl.setText(f"Mouth: {info['mouth_state']}")
        self.posture_lbl.setText(f"Posture: {info['posture']}")
        self.arms_lbl.setText(f"Arms: {info['arms_state']}")
        self.left_hand_lbl.setText(f"Left Hand: {info['hands']['left']}")
        self.right_hand_lbl.setText(f"Right Hand: {info['hands']['right']}")
        self.waving_lbl.setText(f"Waving: {'Yes' if info['waving'] else 'No'}")
        self.actor_status_lbl.setText(f"Actor Status: {info['actor_quality']}")

    # -----------------------------------------------------
    def close_app(self):
        self.running = False
        if self.capture:
            self.capture.release()
        self.close()

# ---------------------------------------------------------
if __name__ == "__main__":
    print("Acting System Terminal Options:")
    print("1: Start Camera")
    print("2: Run Video")
    print("3: Quit")
    choice = input("Enter choice: ")

    import os
    import sys
    from PyQt5.QtWidgets import QApplication

    if choice not in ["1", "2"]:
        print("Exiting.")
        sys.exit(0)

    app = QApplication(sys.argv)
    window = ActingSystemApp()

    if choice == "2":
        print("Select a video in the dialog...")
        window.load_video()
    else:
        window.start_camera()

    window.show()
    sys.exit(app.exec_())
