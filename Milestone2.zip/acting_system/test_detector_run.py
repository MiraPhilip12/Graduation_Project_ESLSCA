# test_detector_run.py
"""
Small test to verify ThreadedVideoCapture and MediapipeWrapper from detector.py.
Usage:
    python test_detector_run.py            # uses camera index 0
    python test_detector_run.py 1         # uses camera index 1
"""

import sys
import time
import cv2

# Import the ThreadedVideoCapture and MediapipeWrapper from your detector.py
# Make sure test_detector_run.py lives in the same folder as detector.py (or PYTHONPATH includes it)
try:
    from detector import ThreadedVideoCapture, MediapipeWrapper
except Exception as e:
    print("Failed to import detector module. Ensure detector.py is in the same folder.")
    print("Import error:", e)
    raise SystemExit(1)

def main():
    # optional camera index from command line
    cam_index = 0
    if len(sys.argv) > 1:
        try:
            cam_index = int(sys.argv[1])
        except ValueError:
            print("Invalid camera index argument, using 0.")

    print(f"Starting threaded capture on index {cam_index}...")
    cam = ThreadedVideoCapture(cam_index, width=640, height=480)
    time.sleep(1.5)  # warm up camera

    frame = cam.read_latest()
    if frame is None:
        print("frame obtained: False")
        print("No frame — check camera index, make sure no other app is using the camera.")
        cam.stop()
        return
    else:
        print("frame obtained: True", "type:", type(frame).__name__, "shape:", frame.shape)

    print("Running MediaPipe processing...")
    try:
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mpw = MediapipeWrapper()
        data, annotated = mpw.process(rgb)
        print("face:", None if data['face_landmarks'] is None else data['face_landmarks'].shape)
        print("left hand:", None if data['left_hand'] is None else data['left_hand'].shape)
        print("right hand:", None if data['right_hand'] is None else data['right_hand'].shape)
        print("pose:", None if data['pose'] is None else data['pose'].shape)
    except Exception as e:
        print("MediaPipe processing failed:", e)
        cam.stop()
        return

    # show annotated image briefly so you can visually confirm (optional)
    try:
        bgr = cv2.cvtColor(annotated, cv2.COLOR_RGB2BGR)
        cv2.imshow("annotated (press any key to close)", bgr)
        print("Showing annotated window for 2 seconds... (press any key to close immediately)")
        # wait up to 2 seconds or until key pressed
        k = cv2.waitKey(2000)
        if k != -1:
            # if a key was pressed, consume it and continue
            pass
        cv2.destroyAllWindows()
    except Exception as e:
        print("Could not show OpenCV window (maybe running headless?):", e)

    cam.stop()
    print("Done.")

if __name__ == "__main__":
    main()
