# patch_scikitplot_all.py
import importlib.util, os, shutil, sys, io

spec = importlib.util.find_spec('scikitplot')
if spec is None or not spec.submodule_search_locations:
    print("scikitplot package not found in this Python environment.")
    sys.exit(1)

pkg_dir = spec.submodule_search_locations[0]
print("scikitplot package directory:", pkg_dir)

# scan .py files in the package
patched_files = []
for root, dirs, files in os.walk(pkg_dir):
    for fname in files:
        if not fname.endswith('.py'):
            continue
        path = os.path.join(root, fname)
        with open(path, 'r', encoding='utf-8') as f:
            src = f.read()
        if "from scipy import interp" in src:
            bak = path + '.bak'
            if not os.path.exists(bak):
                shutil.copy2(path, bak)
                print("Backup created:", bak)
            new_import = (
                "try:\n"
                "    from scipy import interp\n"
                "except Exception:\n"
                "    from numpy import interp\n"
            )
            src2 = src.replace("from scipy import interp", new_import)
            with open(path, 'w', encoding='utf-8') as f:
                f.write(src2)
            patched_files.append(path)
            print("Patched:", path)

if not patched_files:
    print("No occurrences of 'from scipy import interp' found in scikitplot .py files.")
else:
    print("Patched files:", len(patched_files))
