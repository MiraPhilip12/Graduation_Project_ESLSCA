# run_vad_stream.py
# Real-time VAD runner that uses audio_vad.VADStream (background thread + resampling)
# Usage: python run_vad_stream.py

import time
from audio_vad import VADStream

def main():
    # Create VADStream with default parameters (aggressiveness 2 is a good middle ground)
    vad = VADStream(aggressiveness=2, vad_sr=16000, frame_ms=30, buffer_seconds=1.0)

    try:
        vad.start()
    except Exception as e:
        print("Failed to start VAD:", e)
        return

    print("VAD started. Speak into the microphone. Press Ctrl+C to stop.")
    try:
        while True:
            # print status on single terminal line; some terminals may not support \r well, replace with newline if needed
            print("Speaking?", vad.is_speaking, end="\r", flush=True)
            time.sleep(0.1)
    except KeyboardInterrupt:
        print("\nStopping...")
    finally:
        vad.stop()
        print("Stopped.")

if __name__ == "__main__":
    main()
