import math
import numpy as np
import cv2  # Make sure cv2 is imported here
from detectors import FaceDetector, PoseDetector, HandDetector, EmotionDetector
from processor import PerPersonProcessor

class ActingSystemWorker:
    def __init__(self):
        self.face_detector = FaceDetector()
        self.pose_detector = PoseDetector()
        self.hand_detector = HandDetector()
        self.emotion_detector = EmotionDetector()
        self.processor = PerPersonProcessor()
        self.actor_counter = 0  # UNIQUE ACTOR ID across frames

    # ============================================================
    # MAIN PROCESS FUNCTION
    # ============================================================
    def process_frame(self, frame):
        h, w = frame.shape[:2]
        actors = {}
        face_centers = []

        # ------------------- FACE DETECTION -----------------------
        faces = self.face_detector.detect(frame)
        for face in faces:
            pid = self.actor_counter
            self.actor_counter += 1  # increment unique ID

            L = face.landmarks.landmark
            face_lms = [(lm.x, lm.y) for lm in L]
            xs = [p[0] for p in face_lms]
            cx = sum(xs) / len(xs)
            face_centers.append((pid, cx))

            # Emotion
            emo = self.emotion_detector.detect_emotion(face_lms)
            if emo not in ["Happy", "Sad", "Angry", "Neutral", "Confused", "Surprised"]:
                emo = "Neutral"

            # Mouth state
            try:
                top = face_lms[13][1]
                bottom = face_lms[14][1]
                mouth_h = abs(bottom - top)
            except:
                mouth_h = 0.01

            talking, shouting = self.processor.update_face(pid, mouth_h)
            if shouting:
                mouth_state = "Shouting"
            elif talking:
                mouth_state = "Talking"
            elif mouth_h > 0.035:
                mouth_state = "Open"
            else:
                mouth_state = "Closed"

            actors[pid] = {
                "face_landmarks": face_lms,
                "pose_landmarks": None,
                "hands_full": [],
                "emotion": emo,
                "mouth_state": mouth_state,
                "hands": {"left": "hidden", "right": "hidden"},
                "posture": "",
                "waving": False,
                "eyes": "",
                "brows": "",
                "arms_state": "Unknown",
                "actor_quality": "Unknown"
            }

        # ------------------- HAND DETECTION -----------------------
        hands = self.hand_detector.detect(frame)
        for hand in hands:
            lms = [(lm.x, lm.y) for lm in hand.landmarks.landmark]
            handedness = getattr(hand, "label", "Unknown")
            avg_x = np.mean([lm[0] for lm in lms])
            best_pid = None
            min_dist = 99
            for pid, cx in face_centers:
                if abs(cx - avg_x) < min_dist:
                    min_dist = abs(cx - avg_x)
                    best_pid = pid
            if best_pid is None:
                continue
            actors[best_pid]["hands_full"].append({"label": handedness, "landmarks": lms})
            if handedness.lower().startswith("l"):
                actors[best_pid]["hands"]["left"] = "visible"
            elif handedness.lower().startswith("r"):
                actors[best_pid]["hands"]["right"] = "visible"

            # Waving detection
            left_x = avg_x if actors[best_pid]["hands"]["left"] == "visible" else None
            right_x = avg_x if actors[best_pid]["hands"]["right"] == "visible" else None
            waving = self.processor.detect_waving(best_pid, left_x, right_x)
            actors[best_pid]["waving"] = waving

        # ------------------- POSE / BODY -----------------------
        poses = self.pose_detector.detect(frame)
        for pose in poses:
            pid = self.actor_counter
            self.actor_counter += 1  # unique ID for pose if not associated with face
            lms = [(lm.x, lm.y) for lm in pose.landmarks.landmark]

            if pid not in actors:
                actors[pid] = {
                    "face_landmarks": None,
                    "hands_full": [],
                    "hands": {"left": "hidden", "right": "hidden"},
                    "emotion": "Neutral",
                    "mouth_state": "Closed",
                    "legs": {"left": "hidden", "right": "hidden"},
                    "posture": "",
                    "waving": False,
                    "eyes": "",
                    "brows": "",
                    "arms_state": "Unknown",
                    "actor_quality": "Unknown"
                }

            actors[pid]["pose_landmarks"] = lms

            # POSTURE: standing, sitting, leaning
            try:
                sh_y = (lms[11][1] + lms[12][1]) / 2
                hip_y = (lms[23][1] + lms[24][1]) / 2
                dx = lms[11][0] - lms[12][0]
                dy = lms[11][1] - lms[12][1]
            except:
                actors[pid]["posture"] = "Unknown"
                continue

            vertical = hip_y - sh_y
            posture = "Standing" if vertical > 0.05 else "Sitting" if vertical < 0.015 else "Standing"
            if dy > 0.03:
                posture = "Leaning Right"
            elif dy < -0.03:
                posture = "Leaning Left"
            actors[pid]["posture"] = posture

            # Arms state detection
            try:
                lwx, lwy = lms[15]
                rwx, rwy = lms[16]
                lsx, lsy = lms[11]
                rsx, rsy = lms[12]
                arms_state = "Neutral"
                if lwx > rsx and rwx < lsx:
                    arms_state = "Crossed"
                if lwy < lsy and rwy < rsy:
                    arms_state = "Both Raised"
                elif lwy < lsy:
                    arms_state = "Left Raised"
                elif rwy < rsy:
                    arms_state = "Right Raised"
                actors[pid]["arms_state"] = arms_state
            except:
                actors[pid]["arms_state"] = "Unknown"

        # ------------------- EYES & BROWS -----------------------
        for pid, info in actors.items():
            F = info["face_landmarks"]
            if F:
                def g(i):
                    return F[i] if i < len(F) else F[0]
                left_eye = abs(g(159)[1] - g(145)[1])
                right_eye = abs(g(386)[1] - g(374)[1])
                eye_h = (left_eye + right_eye) / 2
                info["eyes"] = "Open" if eye_h > 0.012 else "Closed"

                browL = g(70)[1]
                browR = g(300)[1]
                nose = g(1)[1]
                if abs(browL - browR) < 0.01:
                    info["brows"] = "Symmetric"
                elif browL > browR:
                    info["brows"] = "Asymmetric"
                else:
                    info["brows"] = "Asymmetric"

        # ------------------- ACTOR QUALITY -----------------------
        for pid, info in actors.items():
            score = 0
            if info["posture"] == "Standing":
                score += 1
            if info["eyes"] == "Open":
                score += 1
            if info["emotion"] != "Neutral":
                score += 1
            if info["hands"]["left"] == "visible" or info["hands"]["right"] == "visible":
                score += 1
            if info["arms_state"] in ["Both Raised", "Left Raised", "Right Raised"]:
                score += 1
            info["actor_quality"] = "Good" if score >= 3 else "Bad"

        return actors

    # ============================================================
    # RENDERING / ANNOTATING
    # ============================================================
    def render(self, frame, actors):
        h, w = frame.shape[:2]

        for pid, info in actors.items():
            # Draw pose skeleton
            if info["pose_landmarks"]:
                for lm in info["pose_landmarks"]:
                    cx = int(lm[0] * w)
                    cy = int(lm[1] * h)
                    cv2.circle(frame, (cx, cy), 4, (255, 255, 0), -1)

            # Draw hands
            for hand in info["hands_full"]:
                for lm in hand["landmarks"]:
                    cx = int(lm[0] * w)
                    cy = int(lm[1] * h)
                    cv2.circle(frame, (cx, cy), 4, (0, 255, 255), -1)

        return frame
