import os
import cv2
import numpy as np
from actor_evaluator import calculate_accuracy  # keep your original accuracy function

class VideoRunner:
    def __init__(self):
        self.videos = []
        self.report_data = {"Good":0, "Moderate":0, "Bad":0, "Total":0}

    # --------------------------
    # Load all boxing videos dynamically
    # --------------------------
    def load_videos(self):
        # Base folder for your dataset
        base_folder = "/Users/fatmamilad/Desktop/dr.ayman/acting_system/videos/Box_DataSet"
        labels = ["Good Performance", "Moderate Performance", "Bad Performance"]
        label_map = {"Good Performance":"Good",
                     "Moderate Performance":"Moderate",
                     "Bad Performance":"Bad"}

        self.videos = []
        for lbl in labels:
            folder = os.path.join(base_folder, lbl)
            if not os.path.exists(folder):
                print(f"❌ Folder not found: {folder}")
                continue
            for f in sorted(os.listdir(folder)):
                if f.endswith(".mp4"):
                    self.videos.append({
                        "path": os.path.join(folder, f),
                        "quality": label_map[lbl]
                    })

        if not self.videos:
            print("❌ No videos found in dataset.")
            return False

        return True

    # --------------------------
    # Placeholder boxing gesture detection
    # Replace with real detection later
    # --------------------------
    def detect_boxing_gesture(self, frame):
        hands = {
            "left": np.random.choice(["up", "down"]),
            "right": np.random.choice(["up", "down"])
        }
        posture = np.random.choice(["guard", "punching", "moving"])

        # Map to quality
        if hands['left']=="up" and hands['right']=="up" and posture=="guard":
            actor_quality = "Good"
        elif hands['left']=="down" and hands['right']=="down":
            actor_quality = "Bad"
        else:
            actor_quality = "Moderate"

        return {"hands":hands, "posture":posture, "actor_quality":actor_quality}

    # --------------------------
    # Evaluate a single video
    # --------------------------
    def evaluate_video(self, video_info, actor_id=0):
        path = video_info["path"]
        quality = video_info["quality"]

        cap = cv2.VideoCapture(path)
        if not cap.isOpened():
            print(f"❌ Cannot open video: {path}")
            return None

        ret, frame = cap.read()
        if not ret:
            print(f"❌ Cannot read video: {path}")
            cap.release()
            return None

        actors = {actor_id: self.detect_boxing_gesture(frame)}
        acc = calculate_accuracy(quality)

        # Terminal output
        print("\n🎬 Video Evaluation")
        print(f"Video       : {os.path.basename(path)}")
        print(f"Actor ID    : {actor_id}")
        print(f"Performance : {quality}")
        print(f"Accuracy    : {acc*100:.2f}%")

        # Update report
        self.report_data[quality] += 1
        self.report_data["Total"] += 1

        cap.release()
        return quality

    # --------------------------
    # Run all videos dynamically
    # --------------------------
    def run(self):
        if not self.load_videos():
            return

        for vid in self.videos:
            self.evaluate_video(vid, actor_id=0)

        # Terminal report summary
        print("\n✅ Evaluation Finished")
        print("===== Report Summary =====")
        for k,v in self.report_data.items():
            print(f"{k} Actors: {v}")
