import sys
import cv2
import numpy as np
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QImage, QPixmap, QFont
from PyQt5.QtCore import Qt, QTimer
from worker import ActingSystemWorker
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from datetime import datetime
import os

# ============================================================
# ACCURACY CALCULATION
# ============================================================
def calculate_accuracy(actor_quality):
    """Placeholder accuracy logic"""
    if actor_quality == "Good":
        return np.random.uniform(0.75, 0.95)
    elif actor_quality == "Moderate":
        return np.random.uniform(0.55, 0.74)
    else:  # Bad
        return np.random.uniform(0.30, 0.54)

# ============================================================
# REPORT GENERATOR
# ============================================================
class ReportGenerator:
    def __init__(self, filename=None):
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self.filename = filename or f"Actor_Report_{timestamp}.pdf"
        self.filepath = os.path.join(os.getcwd(), self.filename)

    def create_report(self, summary_data=None, metrics=None, comments=""):
        c = canvas.Canvas(self.filepath, pagesize=A4)
        width, height = A4

        c.setFont("Helvetica-Bold", 20)
        c.setFillColor(colors.darkgreen)
        c.drawCentredString(width / 2, height - 50, "Acting System Report")

        c.setFont("Helvetica", 12)
        c.setFillColor(colors.black)
        c.drawString(50, height - 80, f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, height - 120, "Summary:")
        c.setFont("Helvetica", 12)
        y = height - 140
        if summary_data:
            for key, value in summary_data.items():
                c.drawString(70, y, f"{key}: {value}")
                y -= 20

        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, y - 10, "Metrics:")
        c.setFont("Helvetica", 12)
        y -= 30
        if metrics:
            for key, value in metrics.items():
                c.drawString(70, y, f"{key}: {value}")
                y -= 20

        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, y - 10, "Comments:")
        c.setFont("Helvetica", 12)
        y -= 30
        c.drawString(70, y, comments)

        c.showPage()
        c.save()
        print(f"Report saved: {self.filepath}")
        return self.filepath

# ============================================================
# MAIN APPLICATION
# ============================================================
class ActingSystemApp(QWidget):
    def __init__(self, mode="camera"):
        super().__init__()

        self.setWindowTitle("Acting System")
        self.setStyleSheet("background-color: #1B3A2F;")

        self.worker = ActingSystemWorker()
        self.capture = None
        self.running = False
        self.videos = []
        self.current_video_index = 0
        self.mode = mode

        self.report_data = {
            "Good Actors": 0,
            "Moderate Actors": 0,
            "Bad Actors": 0,
            "Total People": 0
        }

        self.build_ui()
        self.showMaximized()

        if self.mode == "camera":
            self.start_camera()
        elif self.mode == "videos":
            self.load_videos()

    # -----------------------------------------------------
    def build_ui(self):
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(25)

        sidebar = QVBoxLayout()
        sidebar.setSpacing(18)
        section_font = QFont("Helvetica", 17, QFont.Bold)
        item_font = QFont("Helvetica", 15)

        # Face
        face_header = QLabel("FACE")
        face_header.setFont(section_font)
        face_header.setStyleSheet("color: #E0F2F1;")
        sidebar.addWidget(face_header)
        self.emotion_lbl = self.make_label(item_font)
        self.mouth_lbl = self.make_label(item_font)
        self.eyes_lbl = self.make_label(item_font)
        self.brows_lbl = self.make_label(item_font)
        sidebar.addWidget(self.emotion_lbl)
        sidebar.addWidget(self.mouth_lbl)
        sidebar.addWidget(self.eyes_lbl)
        sidebar.addWidget(self.brows_lbl)
        sidebar.addSpacing(20)

        # Body
        body_header = QLabel("BODY")
        body_header.setFont(section_font)
        body_header.setStyleSheet("color: #E0F2F1;")
        sidebar.addWidget(body_header)
        self.posture_lbl = self.make_label(item_font)
        self.arms_lbl = self.make_label(item_font)
        sidebar.addWidget(self.posture_lbl)
        sidebar.addWidget(self.arms_lbl)
        sidebar.addSpacing(20)

        # Hands
        hands_header = QLabel("HANDS")
        hands_header.setFont(section_font)
        hands_header.setStyleSheet("color: #E0F2F1;")
        sidebar.addWidget(hands_header)
        self.left_hand_lbl = self.make_label(item_font)
        self.right_hand_lbl = self.make_label(item_font)
        self.waving_lbl = self.make_label(item_font)
        sidebar.addWidget(self.left_hand_lbl)
        sidebar.addWidget(self.right_hand_lbl)
        sidebar.addWidget(self.waving_lbl)
        sidebar.addSpacing(20)

        # Other
        other_header = QLabel("OTHER")
        other_header.setFont(section_font)
        other_header.setStyleSheet("color: #E0F2F1;")
        sidebar.addWidget(other_header)
        self.actor_status_lbl = self.make_label(item_font)
        self.people_count_lbl = self.make_label(item_font)
        sidebar.addWidget(self.actor_status_lbl)
        sidebar.addWidget(self.people_count_lbl)
        sidebar.addStretch()
        main_layout.addLayout(sidebar, 1)

        # Video display
        self.video_label = QLabel()
        self.video_label.setStyleSheet(
            "background-color: black; border-radius: 10px; border: 2px solid #E0F2F1;"
        )
        self.video_label.setFixedSize(960, 720)
        main_layout.addWidget(self.video_label, 3, alignment=Qt.AlignCenter)

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)

    # -----------------------------------------------------
    def make_label(self, font):
        lbl = QLabel("-")
        lbl.setFont(font)
        lbl.setStyleSheet("color: #F4F4F4;")
        return lbl

    # -----------------------------------------------------
    def start_camera(self):
        if self.running:
            return
        self.capture = cv2.VideoCapture(0)
        if not self.capture.isOpened():
            print("Error: Camera not found.")
            return
        self.running = True
        self.timer.start(15)

    # -----------------------------------------------------
    def load_videos(self):
        base_folder = "/Users/fatmamilad/Desktop/dr.ayman/acting_system/videos/Box_DataSet"
        categories = ["Good Performance", "Moderate Performance", "Bad Performance"]

        video_files = []
        for cat in categories:
            folder_path = os.path.join(base_folder, cat)
            if os.path.exists(folder_path):
                for f in sorted(os.listdir(folder_path)):
                    if f.endswith(".mp4"):
                        video_files.append((os.path.join(folder_path, f), cat.split()[0]))  # Good / Moderate / Bad

        if not video_files:
            print("No videos found in dataset.")
            return

        # Store as list of dicts with path and label
        self.videos = [{"path": v[0], "quality": v[1]} for v in video_files]
        self.current_video_index = 0
        self.capture = cv2.VideoCapture(self.videos[self.current_video_index]["path"])
        self.running = True
        self.timer.start(30)

    # -----------------------------------------------------
    def switch_video(self):
        self.current_video_index += 1
        if self.current_video_index >= len(self.videos):
            self.running = False
            return
        self.capture = cv2.VideoCapture(self.videos[self.current_video_index]["path"])

    # -----------------------------------------------------
    def update_frame(self):
        if not self.running or not self.capture:
            return

        ret, frame = self.capture.read()
        if not ret:
            if self.mode == "videos":
                self.switch_video()
            return

        frame = cv2.resize(frame, (960, 720))
        actors = self.worker.process_frame(frame)
        annotated = self.worker.render(frame.copy(), actors)

        # Video labels and accuracy
        if self.mode == "videos":
            video_info = self.videos[self.current_video_index]
            label_text = os.path.basename(video_info["path"])
            cv2.putText(annotated, label_text, (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

            if actors:
                for pid, info in actors.items():
                    quality = video_info["quality"]
                    final_label = f"{quality} Acting"
                    acc = calculate_accuracy(quality)

                    # Update report
                    if quality == "Good":
                        self.report_data["Good Actors"] += 1
                    elif quality == "Moderate":
                        self.report_data["Moderate Actors"] += 1
                    else:
                        self.report_data["Bad Actors"] += 1
                    self.report_data["Total People"] += 1

                    # Terminal output
                    print("\n🎬 Video Evaluation")
                    print(f"Actor ID : {pid}")
                    print(f"Video    : {os.path.basename(video_info['path'])}")
                    print(f"Result   : {final_label}")
                    print(f"Accuracy : {acc * 100:.2f}%")

        rgb = cv2.cvtColor(annotated, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        img = QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888)
        self.video_label.setPixmap(QPixmap.fromImage(img))

        if isinstance(actors, dict) and actors:
            pid = list(actors.keys())[0]
            self.update_sidebar(actors[pid], len(actors))

    # -----------------------------------------------------
    def update_sidebar(self, info, count):
        self.emotion_lbl.setText(f"Emotion: {info['emotion']}")
        self.mouth_lbl.setText(f"Mouth: {info['mouth_state']}")
        self.eyes_lbl.setText(f"Eyes: {info['eyes']}")
        self.brows_lbl.setText(f"Brows: {info['brows']}")
        self.posture_lbl.setText(f"Posture: {info['posture']}")
        self.arms_lbl.setText(f"Arms: {info['arms_state']}")
        self.left_hand_lbl.setText(f"Left Hand: {info['hands']['left']}")
        self.right_hand_lbl.setText(f"Right Hand: {info['hands']['right']}")
        self.waving_lbl.setText(f"Waving: {'Yes' if info['waving'] else 'No'}")
        self.actor_status_lbl.setText(f"Actor Status: {info['actor_quality']}")
        self.people_count_lbl.setText(f"People in Frame: {count}")

    # -----------------------------------------------------
    def generate_report(self):
        rg = ReportGenerator()
        summary = self.report_data
        metrics = {"Accuracy": "-", "Precision": "-", "Recall": "-", "F1 Score": "-"}
        comments = "This report summarizes actor behavior detected in videos."
        rg.create_report(summary, metrics, comments)

# ============================================================
# ENTRY POINT
# ============================================================
if __name__ == "__main__":
    while True:
        print("\n====== ACTING SYSTEM ======")
        print("1 - Camera")
        print("2 - Videos")
        print("3 - Quit")
        choice = input("Choose option: ")

        if choice == "1":
            app = QApplication(sys.argv)
            window = ActingSystemApp(mode="camera")
            window.show()
            sys.exit(app.exec_())

        elif choice == "2":
            app = QApplication(sys.argv)
            window = ActingSystemApp(mode="videos")
            window.show()
            app.exec_()
            window.generate_report()
            sys.exit()

        elif choice == "3":
            print("👋 Exiting system")
            break

        else:
            print("❌ Invalid option")
