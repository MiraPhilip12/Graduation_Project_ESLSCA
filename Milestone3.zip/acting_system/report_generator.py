from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from datetime import datetime
import os

class ReportGenerator:
    def __init__(self, filename=None):
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self.filename = filename or f"Actor_Report_{timestamp}.pdf"
        self.filepath = os.path.join(os.getcwd(), self.filename)

    def create_report(self, summary_data=None, metrics=None, comments=""):
        """
        summary_data: dict, e.g., {"Good Actors": 3, "Bad Actors": 1, "Total People": 4}
        metrics: dict, e.g., {"Accuracy": 0.92, "Precision": 0.91, "Recall": 0.93, "F1 Score": 0.92}
        comments: string
        """

        c = canvas.Canvas(self.filepath, pagesize=A4)
        width, height = A4

        # Title
        c.setFont("Helvetica-Bold", 20)
        c.setFillColor(colors.darkgreen)
        c.drawCentredString(width / 2, height - 50, "Acting System Report")

        # Date
        c.setFont("Helvetica", 12)
        c.setFillColor(colors.black)
        c.drawString(50, height - 80, f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        # Summary Section
        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, height - 120, "Summary:")
        c.setFont("Helvetica", 12)
        y = height - 140
        if summary_data:
            for key, value in summary_data.items():
                c.drawString(70, y, f"{key}: {value}")
                y -= 20

        # Metrics Section
        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, y - 10, "Metrics:")
        c.setFont("Helvetica", 12)
        y -= 30
        if metrics:
            for key, value in metrics.items():
                c.drawString(70, y, f"{key}: {value}")
                y -= 20

        # Comments Section
        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, y - 10, "Comments:")
        c.setFont("Helvetica", 12)
        y -= 30
        c.drawString(70, y, comments)

        c.showPage()
        c.save()
        print(f"Report saved: {self.filepath}")
        return self.filepath
