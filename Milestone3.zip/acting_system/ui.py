import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
    QGroupBox, QTextEdit, QGridLayout, QFrame, QSpacerItem, QSizePolicy,
    QScrollArea
)
from PyQt5.QtGui import QFont, QPixmap
from PyQt5.QtCore import Qt

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Human Motion Analyzer – Professional Dark Edition")
        self.setMinimumSize(1400, 820)

        # -----------------------------
        # GLOBAL FONT
        # -----------------------------
        font = QFont("Segoe UI", 11)
        self.setFont(font)

        # -----------------------------
        # MAIN WRAPPER
        # -----------------------------
        main_widget = QWidget()
        main_layout = QHBoxLayout(main_widget)
        main_widget.setStyleSheet("background-color: #111111;")

        # -----------------------------
        # LEFT SIDEBAR
        # -----------------------------
        sidebar = QVBoxLayout()
        sidebar.setSpacing(20)

        # SECTION TITLE
        left_title = QLabel("DETECTION PANELS")
        left_title.setStyleSheet("""
            color: #00FF99;
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 5px;
        """)
        sidebar.addWidget(left_title)

        # FACE
        self.face_box = self.create_status_box("FACE DETECTION")
        sidebar.addWidget(self.face_box)

        # BODY
        self.body_box = self.create_status_box("BODY DETECTION")
        sidebar.addWidget(self.body_box)

        # HANDS
        self.hands_box = self.create_status_box("HAND GESTURES")
        sidebar.addWidget(self.hands_box)

        # OTHER
        self.other_box = self.create_status_box("OTHER EVENTS")
        sidebar.addWidget(self.other_box)

        sidebar.addStretch()

        # -----------------------------
        # CENTER VIDEO PANEL
        # -----------------------------
        center_layout = QVBoxLayout()

        video_frame = QGroupBox("VIDEO ANALYSIS")
        video_frame.setStyleSheet("""
            QGroupBox {
                color: #00FF99;
                font-size: 18px;
                border: 2px solid #00FF99;
                border-radius: 12px;
                margin-top: 10px;
            }
        """)

        video_layout = QVBoxLayout(video_frame)
        video_layout.setSpacing(12)

        # Video Display
        self.video_label = QLabel()
        self.video_label.setFixedSize(780, 480)
        self.video_label.setStyleSheet("""
            background-color: #000;
            border: 2px solid #222;
            border-radius: 10px;
        """)
        self.video_label.setAlignment(Qt.AlignCenter)
        video_layout.addWidget(self.video_label)

        # Controls
        controls_layout = QHBoxLayout()

        self.btn_start = QPushButton("Start Video")
        self.btn_camera = QPushButton("Start Camera")
        self.btn_stop = QPushButton("Stop")
        self.btn_export = QPushButton("Export PDF")

        for btn in [self.btn_start, self.btn_camera]:
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #00CC77;
                    padding: 8px 20px;
                    font-weight: bold;
                    font-size: 14px;
                    color: #FFF;
                    border-radius: 8px;
                }
                QPushButton:hover {
                    background-color: #00EE88;
                }
            """)

        for btn in [self.btn_stop, self.btn_export]:
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #333;
                    padding: 8px 20px;
                    font-size: 13px;
                    color: #DDD;
                    border-radius: 8px;
                }
                QPushButton:hover {
                    background-color: #444;
                }
            """)

        controls_layout.addWidget(self.btn_start)
        controls_layout.addWidget(self.btn_camera)
        controls_layout.addWidget(self.btn_stop)
        controls_layout.addWidget(self.btn_export)
        controls_layout.addStretch()

        video_layout.addLayout(controls_layout)
        center_layout.addWidget(video_frame)

        # -----------------------------
        # RIGHT PANEL (Results)
        # -----------------------------
        right_panel = QVBoxLayout()
        right_panel.setSpacing(20)

        result_title = QLabel("DETECTION RESULTS")
        result_title.setStyleSheet("""
            color: #00FF99;
            font-size: 20px;
            font-weight: bold;
        """)
        right_panel.addWidget(result_title)

        # HISTORY
        history_box = QGroupBox("History")
        history_box.setStyleSheet("""
            QGroupBox {
                color: #00FF99;
                border: 2px solid #00FF99;
                border-radius: 10px;
                font-size: 16px;
            }
        """)
        history_layout = QVBoxLayout(history_box)

        self.history_area = QTextEdit()
        self.history_area.setReadOnly(True)
        self.history_area.setStyleSheet("""
            background-color: #000;
            color: #00FF99;
            padding: 8px;
            border-radius: 8px;
            border: 1px solid #222;
        """)
        history_layout.addWidget(self.history_area)
        right_panel.addWidget(history_box)

        right_panel.addStretch()

        # -----------------------------
        # FINAL LAYOUT ATTACH
        # -----------------------------
        main_layout.addLayout(sidebar, 2)
        main_layout.addLayout(center_layout, 5)
        main_layout.addLayout(right_panel, 3)

        self.setCentralWidget(main_widget)

    # -------------------------------------------------
    # CUSTOM STATUS BOX GENERATOR
    # -------------------------------------------------
    def create_status_box(self, title):
        group = QGroupBox(title)
        group.setStyleSheet("""
            QGroupBox {
                color: #00FF99;
                border: 1.8px solid #00FF99;
                border-radius: 10px;
                font-size: 15px;
                margin-top: 10px;
            }
        """)

        layout = QVBoxLayout(group)

        label = QLabel("No data yet")
        label.setStyleSheet("color: white; font-size: 13px;")
        layout.addWidget(label)

        setattr(self, f"{title.lower().replace(' ', '_')}_label", label)
        return group
