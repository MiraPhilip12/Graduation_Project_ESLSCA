import sys
import os

# ===============================
# ACTING EVALUATION LOGIC
# ===============================

def evaluate_video(video_path):
    """
    Evaluate acting performance from a video
    Returns accuracy and Good / Bad label
    """
    if not os.path.exists(video_path):
        raise FileNotFoundError(f"Video not found: {video_path}")

    # --------------------------------------------------
    # 🔽 NEW LOGIC FROM YOUR TEAMMATE
    # --------------------------------------------------
    # Example mock accuracy, replace with real evaluation logic
    accuracy = 0.78
    threshold = 0.6
    # --------------------------------------------------

    result = "Good Acting" if accuracy >= threshold else "Bad Acting"

    return {
        "accuracy": round(accuracy, 2),
        "result": result
    }

def evaluate_all_videos(folder="videos"):
    """
    Evaluate all mp4 videos in the videos folder
    """
    results = {}

    if not os.path.exists(folder):
        print("❌ videos folder not found")
        return results

    for file in os.listdir(folder):
        if file.lower().endswith(".mp4"):
            path = os.path.join(folder, file)
            results[file] = evaluate_video(path)

    return results

# ===============================
# MAIN SYSTEM (ENTRY POINT)
# ===============================

def main():
    while True:
        print("\nSelect Mode:")
        print("1 - Camera (not implemented here)")
        print("2 - Videos (Acting Evaluation)")
        print("3 - Quit")

        choice = input("Enter choice: ").strip()

        if choice == "1":
            print("📷 Camera mode coming soon...")

        elif choice == "2":
            print("\n🎥 Evaluating acting videos...\n")

            results = evaluate_all_videos("videos")

            if not results:
                print("No videos found.")
                continue

            for video, res in results.items():
                print(f"Video    : {video}")
                print(f"Result   : {res['result']}")
                print(f"Accuracy : {res['accuracy'] * 100:.1f}%")
                print("-" * 30)

            print("✅ Evaluation finished")

        elif choice == "3":
            print("👋 Exiting system")
            break

        else:
            print("❌ Invalid choice, try again")

# ===============================
# RUN SYSTEM
# ===============================

if __name__ == "__main__":
    main()
